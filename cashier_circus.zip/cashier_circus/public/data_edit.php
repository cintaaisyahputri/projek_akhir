<?php
ob_start();
session_start();


include '../app/middleware/app.php';


if (!isset($_SESSION['admin_name'])) {
    $_SESSION['redirect_intent'] = 'data_edit.php';
    header('Location: ../login.php');
    exit();
}


function logAdminActivity($pdo, $adminId, $action, $details = '') {
    try {
        $stmt = $pdo->prepare("INSERT INTO session_logs (admin_id, action, details, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->execute([$adminId, $action, $details]);
    } catch (Exception $e) {
        error_log("Log kegagalan di arena admin: " . $e->getMessage() . " pada " . date('Y-m-d H:i:s'));
    }
}


$adminId = $_SESSION['admin_id'] ?? null;
if (!$adminId) {
    $stmt = $pdo->prepare("SELECT id FROM admins WHERE name = ?");
    $stmt->execute([$_SESSION['admin_name']]);
    $admin = $stmt->fetch();
    $adminId = $admin['id'] ?? 1;
    $_SESSION['admin_id'] = $adminId;
}


if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}


$table = filter_input(INPUT_GET, 'table', FILTER_SANITIZE_STRING);
$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);

$allowed_tables = ['products', 'customers', 'categories', 'admins'];
if (!in_array($table, $allowed_tables) || !$id) {
    $_SESSION['message'] = ['type' => 'error', 'text' => 'Tabel atau ID tidak valid.'];
    header('Location: data_admin.php');
    exit();
}


$data = [];
try {
    switch ($table) {
        case 'products':
            $stmt = $pdo->prepare("SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.id = ?");
            $stmt->execute([$id]);
            $data = $stmt->fetch(PDO::FETCH_ASSOC);
            break;
        case 'customers':
            $stmt = $pdo->prepare("SELECT * FROM customers WHERE id = ?");
            $stmt->execute([$id]);
            $data = $stmt->fetch(PDO::FETCH_ASSOC);
            break;
        case 'categories':
            $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
            $stmt->execute([$id]);
            $data = $stmt->fetch(PDO::FETCH_ASSOC);
            break;
        case 'admins':
            $stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
            $stmt->execute([$id]);
            $data = $stmt->fetch(PDO::FETCH_ASSOC);
            break;
    }

    if (!$data) {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Data tidak ditemukan.'];
        header('Location: data_admin.php');
        exit();
    }
} catch (Exception $e) {
    $_SESSION['message'] = ['type' => 'error', 'text' => 'Gagal mengambil data: ' . $e->getMessage()];
    header('Location: data_admin.php');
    exit();
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_data'])) {
    $csrf_token = $_POST['csrf_token'] ?? '';

    if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $csrf_token)) {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Validasi token CSRF gagal.'];
        header('Location: data_edit.php?table=' . $table . '&id=' . $id);
        exit();
    }

    try {
        $pdo->beginTransaction();

        switch ($table) {
            case 'products':
                $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
                $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
                $price = filter_input(INPUT_POST, 'price', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                $stock = filter_input(INPUT_POST, 'stock', FILTER_SANITIZE_NUMBER_INT);
                $category_id = filter_input(INPUT_POST, 'category_id', FILTER_SANITIZE_NUMBER_INT);

                $image = $data['image'];
                if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                    $target_dir = "../public/assets/images/";
                    if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
                    $image_name = uniqid() . '_' . basename($_FILES["image"]["name"]);
                    $target_file = $target_dir . $image_name;
                    $image_file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
                    $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
                    $max_size = 2000000;

                    if ($_FILES['image']['size'] > $max_size) throw new Exception("Gambar terlalu besar, maksimal 2MB.");
                    if (!in_array($image_file_type, $allowed_types)) throw new Exception("Hanya file JPG, JPEG, PNG, atau GIF yang diizinkan.");
                    if (!move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) throw new Exception("Gagal unggah gambar, periksa izin direktori.");
                    $image = $image_name;
                }

                $sql = "UPDATE products SET name = ?, description = ?, price = ?, stock = ?, category_id = ?";
                $params = [$name, $description, $price, $stock, $category_id];
                if (isset($image) && $image != $data['image']) {
                    $sql .= ", image = ?";
                    $params[] = $image;
                }
                $sql .= " WHERE id = ?";
                $params[] = $id;
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
                break;

            case 'customers':
                $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
                $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
                $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
                $address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_STRING);

                $stmt = $pdo->prepare("UPDATE customers SET name = ?, email = ?, phone = ?, address = ? WHERE id = ?");
                $stmt->execute([$name, $email, $phone, $address, $id]);
                break;

            case 'categories':
                $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
                $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);

                $stmt = $pdo->prepare("UPDATE categories SET name = ?, description = ? WHERE id = ?");
                $stmt->execute([$name, $description, $id]);
                break;

            case 'admins':
                $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
                $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
                $password = !empty($_POST['password']) ? password_hash($_POST['password'], PASSWORD_DEFAULT) : null;

                if ($password) {
                    $stmt = $pdo->prepare("UPDATE admins SET name = ?, email = ?, password = ? WHERE id = ?");
                    $stmt->execute([$name, $email, $password, $id]);
                } else {
                    $stmt = $pdo->prepare("UPDATE admins SET name = ?, email = ? WHERE id = ?");
                    $stmt->execute([$name, $email, $id]);
                }
                break;
        }

        $pdo->commit();
        logAdminActivity($pdo, $adminId, 'edited_data', "Tabel: $table, ID: $id");
        $_SESSION['message'] = ['type' => 'success', 'text' => 'Data berhasil diubah!'];
        header('Location: data_admin.php');
        exit();
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Gagal mengubah data: ' . $e->getMessage()];
        header('Location: data_edit.php?table=' . $table . '&id=' . $id);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data - Sirkus Kerajaan</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/5/w3.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
    <link href="https://fonts.googleapis.com/css2?family=MedievalSharp&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../public/assets/css/public.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            background: url('../public/assets/images/starbg.jpeg') no-repeat center/cover;
            font-family: 'MedievalSharp', cursive;
            color: var(--hunyadi-yellow);
        }
        .w3-card {
            background: rgba(0, 0, 0, 0.85);
            border: 2px solid var(--sienna);
            box-shadow: 0 0 20px var(--orange-crayola);
        }
        .w3-bar {
            background: linear-gradient(45deg, var(--sienna), var(--sandy-brown));
        }
        .w3-bar-item:hover {
            background: var(--orange-crayola);
            transform: scale(1.05);
        }
        input, select, textarea, button {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid var(--sienna);
            color: var(--hunyadi-yellow);
            padding: 8px;
            border-radius: 8px;
            transition: 0.3s ease;
        }
        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: var(--orange-crayola);
            box-shadow: 0 0 8px rgba(245, 133, 73, 0.5);
        }
        button {
            background: linear-gradient(45deg, var(--sienna), var(--orange-crayola));
            cursor: pointer;
        }
        button:hover {
            background: linear-gradient(45deg, var(--orange-crayola), var(--sienna));
            transform: scale(1.05);
        }
        .card {
            margin: 20px auto;
            padding: 15px;
            border: 2px dashed var(--sandy-brown);
            background: rgba(0, 0, 0, 0.7);
            width: 80%;
            max-width: 600px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
            transition: 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
            background: rgba(86, 42, 14, 0.8);
        }
    </style>
</head>
<body>

    <div class="w3-top">
        <div class="w3-bar w3-card">
            <a href="data_admin.php" class="w3-bar-item w3-button w3-large">&larr; Kembali</a>
            <div class="w3-bar-item w3-wide">Sirkus Kerajaan - Edit Data</div>
        </div>
    </div>

    <div class="w3-container w3-padding-64" style="margin-top: 50px;">
        <div class="card">
            <h2>Edit <?= ucfirst($table) ?></h2>
            <?php if (isset($_SESSION['message'])): ?>
                <p class="w3-text-<?= $_SESSION['message']['type'] === 'success' ? 'green' : 'red' ?>">
                    <?= $_SESSION['message']['text'] ?>
                </p>
                <?php unset($_SESSION['message']); ?>
            <?php endif; ?>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="edit_data" value="1">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <?php
                if ($table === 'products') {
                    $stmt = $pdo->prepare("SELECT id, name AS category_name FROM categories");
                    $stmt->execute();
                    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
                ?>
                    <div class="mb-4">
                        <label>Nama:</label>
                        <input type="text" name="name" value="<?= htmlspecialchars($data['name']) ?>" required>
                    </div>
                    <div class="mb-4">
                        <label>Deskripsi:</label>
                        <textarea name="description" required><?= htmlspecialchars($data['description']) ?></textarea>
                    </div>
                    <div class="mb-4">
                        <label>Harga:</label>
                        <input type="number" name="price" value="<?= htmlspecialchars($data['price']) ?>" required step="0.01">
                    </div>
                    <div class="mb-4">
                        <label>Stok:</label>
                        <input type="number" name="stock" value="<?= htmlspecialchars($data['stock']) ?>" required>
                    </div>
                    <div class="mb-4">
                        <label>Kategori:</label>
                        <select name="category_id" required>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>" <?= $data['category_id'] == $cat['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($cat['category_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-4">
                        <label>Gambar Saat Ini:</label>
                        <img src="../public/assets/images/<?= htmlspecialchars($data['image']) ?>" alt="Gambar Produk" style="width:100px;">
                    </div>
                    <div class="mb-4">
                        <label>Gambar Baru (opsional):</label>
                        <input type="file" name="image">
                    </div>
                <?php
                } elseif ($table === 'customers') {
                ?>
                    <div class="mb-4">
                        <label>Nama:</label>
                        <input type="text" name="name" value="<?= htmlspecialchars($data['name']) ?>" required>
                    </div>
                    <div class="mb-4">
                        <label>Email:</label>
                        <input type="email" name="email" value="<?= htmlspecialchars($data['email']) ?>" required>
                    </div>
                    <div class="mb-4">
                        <label>Telepon:</label>
                        <input type="text" name="phone" value="<?= htmlspecialchars($data['phone'] ?? '') ?>">
                    </div>
                    <div class="mb-4">
                        <label>Alamat:</label>
                        <textarea name="address"><?= htmlspecialchars($data['address'] ?? '') ?></textarea>
                    </div>
                <?php
                } elseif ($table === 'categories') {
                ?>
                    <div class="mb-4">
                        <label>Nama:</label>
                        <input type="text" name="name" value="<?= htmlspecialchars($data['name']) ?>" required>
                    </div>
                    <div class="mb-4">
                        <label>Deskripsi:</label>
                        <textarea name="description"><?= htmlspecialchars($data['description'] ?? '') ?></textarea>
                    </div>
                <?php
                } elseif ($table === 'admins') {
                ?>
                    <div class="mb-4">
                        <label>Nama:</label>
                        <input type="text" name="name" value="<?= htmlspecialchars($data['name']) ?>" required>
                    </div>
                    <div class="mb-4">
                        <label>Email:</label>
                        <input type="email" name="email" value="<?= htmlspecialchars($data['email']) ?>" required>
                    </div>
                    <div class="mb-4">
                        <label>Password Baru (kosongkan jika tidak ubah):</label>
                        <input type="password" name="password">
                    </div>
                <?php
                }
                ?>
                <button type="submit">Simpan Perubahan</button>
            </form>
        </div>
    </div>
    
<footer class="w3-container w3-footer w3-center" style="padding:32px">
    <a href="https://github.com/cintaaisyahputri" class="w3-button w3-margin-bottom"><i class="fa fa-arrow-up w3-margin-right"></i>To the top</a>
    <p>Powered by the Grand Steampunk Circus Emporium
        MADE BY CINTA AISYAH PUTRI XI RPL 1
    </p>
</footer>

    <script>
        <?php if (isset($_SESSION['message'])): ?>
            Swal.fire({
                title: '<?= $_SESSION['message']['type'] === 'success' ? 'Success' : 'Error' ?>',
                text: '<?= $_SESSION['message']['text'] ?>',
                icon: '<?= $_SESSION['message']['type'] ?>'
            });
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>
    </script>
</body>
</html>
<?php ob_end_flush(); ?>