<?php
session_start();
// Clear any residual session data
if (session_status() === PHP_SESSION_ACTIVE) {
  session_unset();
  session_destroy();
  session_start();
  session_regenerate_id(true);
  session_write_close();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tirai Sirkus Turun...</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      background: url('../public/assets/images/starbg.jpeg') no-repeat center/cover;
      font-family: 'MedievalSharp', cursive;
      color: var(--hunyadi-yellow);
      overflow: hidden;
    }
    :root {
      --hunyadi-yellow: #F5C518;
      --sienna: #562A0E;
      --orange-crayola: #F58549;
      --sandy-brown: #EEC170;
    }
    .curtain-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.8);
      opacity: 0;
      transition: opacity 1s ease-in-out;
      z-index: 9998;
    }
    .curtain-overlay.active {
      opacity: 1;
    }
    .curtain {
      position: fixed;
      top: -100%;
      left: 0;
      width: 100%;
      height: 100%;
      background: url('../public/assets/images/tirai.png') no-repeat center/cover;
      transition: top 2s ease-in-out;
      z-index: 9999;
    }
    .curtain.active {
      top: 0;
    }
  </style>
  <link rel="stylesheet" href="public/assets/css/public.css" onerror="this.style.display='none';">
</head>
<body>
  <div class="curtain-overlay active"></div>
  <div class="curtain active"></div>

  <script>
    console.log('Tirai mulai turun...');
    setTimeout(() => {
      document.querySelector('.curtain').classList.remove('active');
      document.querySelector('.curtain-overlay').classList.remove('active');
      setTimeout(() => {
        console.log('Mengarah ke redirect URL: <?= htmlspecialchars($_GET['redirect'] ?? 'login.php') ?>');
        window.location.href = '<?= htmlspecialchars($_GET['redirect'] ?? 'login.php') ?>';
      }, 1000); // Total 3 detik: turun (2s) + fade out (1s)
    }, 2000);

    if (!document.querySelector('.curtain')) {
      alert('Tirai tidak ditemukan! Periksa gambar tirai.png');
    }
  </script>
  <footer class="w3-container w3-footer w3-center" style="padding:32px">
    <a href="https://github.com/cintaaisyahputri" class="w3-button w3-margin-bottom"><i class="fa fa-arrow-up w3-margin-right"></i>To the top</a>
    <p>Powered by the Grand Steampunk Circus Emporium
        MADE BY CINTA AISYAH PUTRI XI RPL 1
    </p>
</footer>
</body>
</html>