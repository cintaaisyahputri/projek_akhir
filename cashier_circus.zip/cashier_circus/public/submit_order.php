<?php
session_start();
include '../app/middleware/app.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Validate CSRF token
  if (!hash_equals($_SESSION['csrf_token'], $_SERVER['HTTP_X_CSRF_TOKEN'])) {
    die(json_encode(['status' => 'error', 'message' => 'CSRF token validation failed']));
  }

  $data = json_decode(file_get_contents('php://input'), true);

  // Validate input data
  $admin_email = filter_var($data['admin_email'], FILTER_VALIDATE_EMAIL);
  $customer_phone = htmlspecialchars(trim($data['customer_phone']));
  $total_payment = floatval($data['total_payment']);
  $total_product = intval($data['total_product']);
  $ordered_products = $data['ordered_products'];

  if (!$admin_email || empty($customer_phone) || $total_payment <= 0 || $total_product <= 0 || !is_array($ordered_products)) {
    die(json_encode(['status' => 'error', 'message' => 'Invalid input data']));
  }

  try {
    // Start transaction
    $pdo->beginTransaction();

    // Insert into orders table
    $stmt = $pdo->prepare("INSERT INTO orders (admin_id, customer_id, total_payment, total_product) VALUES (:admin_id, :customer_id, :total_payment, :total_product)");
    $stmt->execute([
      ':admin_id' => 1, // Adjust this according to your logic
      ':customer_id' => null, // You'll need to get the customer ID from your database if needed
      ':total_payment' => $total_payment,
      ':total_product' => $total_product,
    ]);

    $orderId = $pdo->lastInsertId();

    // Insert ordered products
    foreach ($ordered_products as $ordered) {
      if (!isset($ordered['product_id'], $ordered['quantity'], $ordered['price']) || $ordered['quantity'] <= 0) {
        throw new Exception("Invalid ordered product data");
      }

      $stmt = $pdo->prepare("INSERT INTO order_product (order_id, product_id, quantity, total_price) VALUES (:order_id, :product_id, :quantity, :total_price)");
      $stmt->execute([
        ':order_id' => $orderId,
        ':product_id' => $ordered['product_id'],
        ':quantity' => $ordered['quantity'],
        ':total_price' => $ordered['quantity'] * $ordered['price'], // Assuming you need the price here
      ]);

      // Update product stock
      $stmt = $pdo->prepare("UPDATE products SET stock = stock - :quantity WHERE id = :product_id");
      $stmt->execute([
        ':quantity' => $ordered['quantity'],
        ':product_id' => $ordered['product_id'],
      ]);
    }

    // Commit transaction
    $pdo->commit();

    echo json_encode(['status' => 'success', 'message' => 'Order placed successfully!', 'updatedStock' => []]); // Add updated stock data if needed
  } catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['status' => 'error', 'message' => 'Error: ' . $e->getMessage()]);
  }
} else {
  die(json_encode(['status' => 'error', 'message' => 'Invalid request method']));
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tambah Pesanan Sirkus</title>
  <link rel="stylesheet" href="assets/css/public.css">
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
<link href="https://fonts.googleapis.com/css2?family=MedievalSharp&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../public/assets/css/index.css"> <!-- Gaya utama dari index -->
<link rel="stylesheet" href="../public/assets/css/circus-footer.css"> <!-- Footer seragam -->
<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    <style>
    body {
      background: linear-gradient(to bottom, var(--orange-crayola), var(--field-drab));
      color: var(--hunyadi-yellow);
      font-family: 'circussant', sans-serif;
      margin: 0;
      padding: 0;
      min-height: 100vh;
      position: relative;
      overflow-x: hidden;
    }
    .container {
      max-width: 900px;
      margin: 20px auto;
      padding: 20px;
      background: rgba(0, 0, 0, 0.85);
      border-radius: 15px;
      box-shadow: 0 0 20px var(--orange-crayola);
      border: 2px solid var(--sienna);
      text-align: center;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
      background: rgba(0, 0, 0, 0.6);
      border: 1px solid var(--sienna);
    }
    th, td {
      padding: 10px;
      text-align: left;
      color: var(--hunyadi-yellow);
      border-bottom: 1px solid var(--sienna);
    }
    th {
      background: linear-gradient(45deg, var(--sienna), var(--sandy-brown));
    }
    .product-quantity {
      width: 60px;
      padding: 5px;
      border: 1px solid var(--sienna);
      border-radius: 5px;
      background: rgba(255, 255, 255, 0.1);
      color: var(--hunyadi-yellow);
    }
    #orderSummary {
      margin-top: 20px;
      padding: 15px;
      background: rgba(var(--field-drab), 0.8);
      border-radius: 10px;
      border: 1px solid var(--hunyadi-yellow);
      text-align: center;
    }
    button {
      background: linear-gradient(45deg, var(--sienna), var(--orange-crayola));
      color: var(--hunyadi-yellow);
      padding: 12px 25px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-family: 'circussant', sans-serif;
      font-size: 1.2em;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    button:hover {
      background: linear-gradient(45deg, var(--orange-crayola), var(--sienna));
      transform: scale(1.05);
    }
    .medieval-container {
      margin: 20px 0;
      padding: 15px;
      border: 2px dashed var(--sandy-brown);
      background: rgba(0, 0, 0, 0.7);
      font-family: 'mediti_', sans-serif;
      color: var(--hunyadi-yellow);
    }
    .medieval-container::before {
      content: "✠"; /* Simbol hiasan awal */
      margin-right: 5px;
    }
    .medieval-container::after {
      content: "⚔"; /* Simbol hiasan akhir */
      margin-left: 5px;
    }
  </style>
</head>
<body>
  <div class="medieval-container">
    <!-- Kamu bisa isi sendiri teks simbol medieval di sini -->
  </div>
</body>
</html>