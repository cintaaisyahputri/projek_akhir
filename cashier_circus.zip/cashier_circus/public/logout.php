<?php
session_start();
require '../app/middleware/app.php';

// Check login status
function checkLogin() {
  if (!isset($_SESSION['admin_name'])) {
    header('Location: ../login.php');
    exit();
  }
}
checkLogin();

// Check if table exists
function tableExists($pdo, $table) {
  try {
    $result = $pdo->query("SELECT 1 FROM $table LIMIT 1");
    return true;
  } catch (Exception $e) {
    return false;
  }
}

// Log session activity
function logSessionActivity($pdo, $adminId, $action) {
  if (!tableExists($pdo, 'session_logs')) {
    error_log("Session logs table does not exist. Skipping session logging at " . date('Y-m-d H:i:s'));
    return;
  }
  try {
    $stmt = $pdo->prepare("INSERT INTO session_logs (admin_id, action, created_at) VALUES (?, ?, NOW())");
    $stmt->execute([$adminId, $action]);
  } catch (Exception $e) {
    error_log("Error logging session activity: " . $e->getMessage() . " at " . date('Y-m-d H:i:s'));
  }
}

// Handle logout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_logout'])) {
  if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $_SESSION['logout_error'] = 'Validasi token CSRF gagal.';
    header('Location: logout.php');
    exit();
  }

  // Log logout activity
  logSessionActivity($pdo, $_SESSION['admin_id'], 'logout');

  // Clear session
  session_unset();
  session_destroy();
  // Regenerate session ID to prevent session fixation
  session_start();
  session_regenerate_id(true);
  session_write_close();
} else {
  // Initialize CSRF token
  if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
  }

  // Fetch recent session logs for display
  $logs = [];
  if (tableExists($pdo, 'session_logs')) {
    try {
      $sessionLogs = $pdo->prepare("SELECT sl.action, sl.created_at, a.name AS admin_name 
                                    FROM session_logs sl 
                                    JOIN admins a ON sl.admin_id = a.id 
                                    ORDER BY sl.created_at DESC LIMIT 10");
      $sessionLogs->execute();
      $logs = $sessionLogs->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
      error_log("Error fetching session logs: " . $e->getMessage() . " at " . date('Y-m-d H:i:s'));
    }
  }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Logout - Sirkus Kerajaan</title>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/5/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
  <link href="https://fonts.googleapis.com/css2?family=MedievalSharp&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../public/assets/css/public.css">
  <link rel="stylesheet" href="../public/assets/css/circus-footer.css">
  <link rel="stylesheet" href="../public/assets/css/circus-login.css">
  <script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    body {
      background: url('../public/assets/images/starbg.jpeg') no-repeat center/cover;
      font-family: 'MedievalSharp', cursive;
      color: var(--hunyadi-yellow);
    }
    .w3-card {
      background: rgba(0, 0, 0, 0.85);
      border: 2px solid var(--sienna);
      box-shadow: 0 0 20px var(--orange-crayola);
    }
    .w3-bar {
      background: linear-gradient(45deg, var(--sienna), var(--sandy-brown));
    }
    .w3-bar-item:hover {
      background: var(--orange-crayola);
      transform: scale(1.05);
    }
    .curtain {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: url('../public/assets/images/tirai.png') repeat-x top;
      z-index: 1000;
      display: none;
    }
    .curtain-left, .curtain-right {
      width: 50%;
      height: 100%;
      position: absolute;
      background: inherit;
      transition: transform 1s ease-in-out;
    }
    .curtain-left {
      left: 0;
      transform: translateX(0);
    }
    .curtain-right {
      right: 0;
      transform: translateX(0);
    }
    .curtain-open .curtain-left {
      transform: translateX(-100%);
    }
    .curtain-open .curtain-right {
      transform: translateX(100%);
    }
    .farewell-message {
      text-align: center;
      font-size: 2rem;
      opacity: 0;
      transition: opacity 1s ease-in;
    }
    .farewell-message.show {
      opacity: 1;
    }
    .logout-container {
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
    }
    .session-log-table {
      margin-top: 40px;
    }
  </style>
</head>
<body class="w3-light-grey">
  <!-- Particles Background -->
  <div id="particles-js" style="position: fixed; width: 100%; height: 100%; z-index: -1;"></div>

  <!-- Curtain Effect -->
  <div class="curtain" id="curtain">
    <div class="curtain-left"></div>
    <div class="curtain-right"></div>
  </div>

  <!-- Navbar -->
  <div class="w3-bar w3-black w3-hide-small">
    <a href="dashboard.php" class="w3-bar-item w3-button"><i class="fa fa-home"></i> Dashboard</a>
    <a href="order.php" class="w3-bar-item w3-button"><i class="fa fa-shopping-cart"></i> Transaksi</a>
    <a href="data_admin.php" class="w3-bar-item w3-button"><i class="fa fa-database"></i> Master Data</a>
    <a href="logout.php" class="w3-bar-item w3-button w3-right"><i class="fa fa-sign-out"></i> Logout</a>
    <a href="#" class="w3-bar-item w3-button w3-right"><i class="fa fa-search"></i></a>
  </div>

  <!-- Sidebar for small screens -->
  <nav class="w3-sidebar w3-bar-block w3-black w3-collapse w3-top w3-hide-large" style="z-index:3;width:250px" id="mySidebar">
    <div class="w3-container w3-display-container w3-padding-16">
      <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
      <h3 class="w3-wide"><b>Sirkus Kerajaan</b></h3>
    </div>
    <div class="w3-padding-64 w3-large w3-text-grey" style="font-weight:bold">
      <a href="dashboard.php" class="w3-bar-item w3-button">Dashboard</a>
      <a href="order.php" class="w3-bar-item w3-button">Transaksi</a>
      <a href="data_admin.php" class="w3-bar-item w3-button">Master Data</a>
      <a href="logout.php" class="w3-bar-item w3-button">Logout</a>
    </div>
  </nav>

  <!-- Overlay for sidebar -->
  <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" id="myOverlay"></div>

  <!-- Main Content -->
  <div class="w3-main" style="margin-left:250px;margin-top:43px;">
    <header class="w3-container w3-center w3-padding-48 w3-card">
      <h1 class="w3-xxxlarge animate__animated animate__fadeIn"><b>Logout - Sirkus Kerajaan</b></h1>
      <h6>Apakah Anda yakin ingin keluar dari sistem?</h6>
    </header>

    <!-- Logout Form -->
    <div class="w3-container w3-padding w3-card logout-container">
      <form id="logoutForm" method="POST" class="w3-container w3-center">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
        <input type="hidden" name="confirm_logout" value="1">
        <button type="submit" class="w3-button w3-red w3-large">Keluar Sekarang</button>
        <a href="dashboard.php" class="w3-button w3-black w3-large w3-margin-left">Batal</a>
      </form>
      <?php if (isset($_SESSION['logout_error'])): ?>
        <div class="w3-panel w3-red w3-padding">
          <?= htmlspecialchars($_SESSION['logout_error']) ?>
          <?php unset($_SESSION['logout_error']); ?>
        </div>
      <?php endif; ?>
    </div>

    <!-- Session Logs -->
    <div class="w3-container w3-padding w3-card session-log-table">
      <h3 class="w3-border-bottom w3-border-light-grey w3-padding-16">Log Aktivitas Sesi</h3>
      <?php if (empty($logs)): ?>
        <p class="w3-text-grey w3-italic">Belum ada log aktivitas atau tabel session_logs tidak ditemukan.</p>
      <?php else: ?>
        <table class="w3-table w3-bordered">
          <thead>
            <tr>
              <th>Admin</th>
              <th>Aksi</th>
              <th>Waktu</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($logs as $log): ?>
              <tr>
                <td><?= htmlspecialchars($log['admin_name']) ?></td>
                <td><?= htmlspecialchars($log['action']) ?></td>
                <td><?= htmlspecialchars(date('d-m-Y H:i:s', strtotime($log['created_at']))) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>

    <!-- Farewell Message -->
    <div class="w3-container w3-center w3-padding-64 farewell-message" id="farewellMessage">
      <h2>Sampai Jumpa di Sirkus Kerajaan!</h2>
      <p>Terima kasih telah menjadi bagian dari pertunjukan kami.</p>
    </div>
  </div>

  <!-- Footer -->
  <footer class="w3-container w3-dark-grey footer">
    <p class="footer__text">Powered by <a href="https://www.w3schools.com/w3css/default.asp" target="_blank">w3.css</a> & Sirkus Kerajaan</p>
  </footer>

  <script>
    // Sidebar toggle
    function w3_open() {
      document.getElementById("mySidebar").style.display = "block";
      document.getElementById("myOverlay").style.display = "block";
    }
    function w3_close() {
      document.getElementById("mySidebar").style.display = "none";
      document.getElementById("myOverlay").style.display = "none";
    }

    // Particles.js configuration
    particlesJS("particles-js", {
      particles: {
        number: { value: 80, density: { enable: true, value_area: 800 } },
        color: { value: "#f58549" },
        shape: { type: "star", stroke: { width: 0, color: "#000000" } },
        opacity: { value: 0.5, random: false },
        size: { value: 3, random: true },
        line_linked: { enable: true, distance: 150, color: "#f58549", opacity: 0.4, width: 1 },
        move: { enable: true, speed: 6, direction: "none", random: false }
      },
      interactivity: {
        detect_on: "canvas",
        events: { onhover: { enable: true, mode: "repulse" }, onclick: { enable: true, mode: "push" } },
        modes: { repulse: { distance: 100, duration: 0.4 }, push: { particles_nb: 4 } }
      }
    });

    // Confetti effect on load
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#f58549', '#f2a65a', '#eec170']
    });

    // Curtain transition effect with fallback
    function showCurtainAndRedirect() {
      const curtain = document.getElementById('curtain');
      const farewellMessage = document.getElementById('farewellMessage');
      curtain.style.display = 'block';
      setTimeout(() => {
        curtain.classList.add('curtain-open');
        farewellMessage.classList.add('show');
      }, 100);
      setTimeout(() => {
        // Correct path to tirai.php in root
        fetch('../tirai.php?redirect=login.php')
          .then(response => {
            if (!response.ok) {
              throw new Error('Tirai page not found');
            }
            return response.text();
          })
          .then(() => {
            window.location.href = '../tirai.php?redirect=login.php';
          })
          .catch(error => {
            console.error('Fallback redirect due to error: ', error);
            window.location.href = '../login.php'; // Fallback to login.php
          });
      }, 2000); // Match animation duration
    }

    // Logout confirmation
    document.getElementById('logoutForm').addEventListener('submit', (e) => {
      e.preventDefault();
      Swal.fire({
        title: 'Konfirmasi Logout',
        text: 'Apakah Anda yakin ingin keluar dari Sirkus Kerajaan?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, Keluar!',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
          showCurtainAndRedirect();
        }
      });
    });

    const farewellMessage = document.getElementById('farewellMessage');
    farewellMessage.addEventListener('mouseover', () => {
      confetti({
        particleCount: 50,
        spread: 50,
        origin: { y: 0.6 },
        colors: ['#f58549', '#f2a65a', '#eec170']
      });
    });
  </script>
</body>
</html>
