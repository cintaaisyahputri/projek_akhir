<?php
ob_start();
session_start();

// Include middleware – Penjaga Gerbang yang Tak Tergoyahkan
include '../app/middleware/app.php';

// Check if admin is logged in – Jika bukan raja, kembali ke gerbang login!
if (!isset($_SESSION['admin_name'])) {
    $_SESSION['redirect_intent'] = 'data_admin.php';
    header('Location: ../login.php');
    exit();
}

// Fungsi untuk log aktivitas – Seperti buku catatan penyihir
function logAdminActivity($pdo, $adminId, $action, $details = '') {
    try {
        $stmt = $pdo->prepare("INSERT INTO session_logs (admin_id, action, details, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->execute([$adminId, $action, $details]);
    } catch (Exception $e) {
        error_log("Log kegagalan di arena admin: " . $e->getMessage() . " pada " . date('Y-m-d H:i:s'));
    }
}

// Ambil ID admin dari sesi
$adminId = $_SESSION['admin_id'] ?? null;
if (!$adminId) {
    $stmt = $pdo->prepare("SELECT id FROM admins WHERE name = ?");
    $stmt->execute([$_SESSION['admin_name']]);
    $admin = $stmt->fetch();
    $adminId = $admin['id'] ?? 1;
    $_SESSION['admin_id'] = $adminId;
}

logAdminActivity($pdo, $adminId, 'entered_data_admin', 'Mulai kelola data kerajaan: products, customers, categories, admins');

// Fungsi untuk cek apakah kolom ada
function columnExists($pdo, $table, $column) {
    try {
        $result = $pdo->query("SHOW COLUMNS FROM $table LIKE '$column'");
        return $result->rowCount() > 0;
    } catch (Exception $e) {
        error_log("Gagal cek kolom $column di $table: " . $e->getMessage());
        return false;
    }
}

// Fetch products with category names – Daftar kuda perang dan pedang mereka
$sql_products = "SELECT p.id AS product_id, p.name AS product_name, p.description, c.name AS category_name, p.price, p.stock, p.image, p.category_id";
if (columnExists($pdo, 'products', 'created_at')) {
    $sql_products .= ", p.created_at";
}
$sql_products .= " FROM products p LEFT JOIN categories c ON p.category_id = c.id";
if (columnExists($pdo, 'products', 'created_at')) {
    $sql_products .= " ORDER BY p.created_at DESC";
} else {
    $sql_products .= " ORDER BY p.id DESC";
}
$stmt_products = $pdo->prepare($sql_products);
$stmt_products->execute();
$products = $stmt_products->fetchAll(PDO::FETCH_ASSOC);

// Fetch customers – Daftar bangsawan pelanggan, setia pada sirkus
$sql_customers = "SELECT id AS customer_id, name, email, phone, address";
if (columnExists($pdo, 'customers', 'created_at')) {
    $sql_customers .= ", created_at";
}
$sql_customers .= ", total_orders 
                  FROM customers 
                  LEFT JOIN (SELECT customer_id, COUNT(*) as total_orders FROM orders GROUP BY customer_id) o ON customers.id = o.customer_id";
if (columnExists($pdo, 'customers', 'created_at')) {
    $sql_customers .= " ORDER BY created_at DESC";
} else {
    $sql_customers .= " ORDER BY id DESC";
}
$stmt_customers = $pdo->prepare($sql_customers);
$stmt_customers->execute();
$customers = $stmt_customers->fetchAll(PDO::FETCH_ASSOC);

// Fetch categories – Kategori arena: tiket, merchandise, breeding kuda
$sql_categories = "SELECT id AS category_id, name AS category_name, description, total_products 
                   FROM categories 
                   LEFT JOIN (SELECT category_id, COUNT(*) as total_products FROM products GROUP BY category_id) p ON categories.id = p.category_id
                   ORDER BY name ASC";
$stmt_categories = $pdo->prepare($sql_categories);
$stmt_categories->execute();
$categories = $stmt_categories->fetchAll(PDO::FETCH_ASSOC);

// Fetch admins – Daftar steward setia, penjaga gerbang sirkus
$sql_admins = "SELECT id AS admin_id, name, email";
if (columnExists($pdo, 'admins', 'last_login')) {
    $sql_admins .= ", last_login";
}
if (columnExists($pdo, 'admins', 'created_at')) {
    $sql_admins .= ", created_at";
}
$sql_admins .= " FROM admins";
if (columnExists($pdo, 'admins', 'last_login')) {
    $sql_admins .= " ORDER BY last_login DESC";
} else {
    $sql_admins .= " ORDER BY id DESC";
}
$stmt_admins = $pdo->prepare($sql_admins);
$stmt_admins->execute();
$admins = $stmt_admins->fetchAll(PDO::FETCH_ASSOC);

// Inisialisasi CSRF token jika belum ada – Kunci gerbang baru
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Proses edit data – Mantra untuk ubah harta kerajaan
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_data'])) {
    $table = filter_input(INPUT_POST, 'table', FILTER_SANITIZE_STRING);
    $id = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT);
    $csrf_token = $_POST['csrf_token'] ?? '';

    // Validasi CSRF – Lindungi dari penyihir jahat!
    if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $csrf_token)) {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Validasi token CSRF gagal.'];
        header('Location: data_admin.php');
        exit();
    }

    // Validasi tabel – Hanya izinkan tabel kerajaan
    $allowed_tables = ['products', 'customers', 'categories', 'admins'];
    if (!in_array($table, $allowed_tables)) {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Tabel tidak valid.'];
        header('Location: data_admin.php');
        exit();
    }

    // Update berdasarkan tabel – Terapkan mantra ubah
    try {
        $pdo->beginTransaction();

        switch ($table) {
            case 'products':
                $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
                $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
                $price = filter_input(INPUT_POST, 'price', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                $stock = filter_input(INPUT_POST, 'stock', FILTER_SANITIZE_NUMBER_INT);
                $category_id = filter_input(INPUT_POST, 'category_id', FILTER_SANITIZE_NUMBER_INT);

                // Handle upload gambar – Seperti simpan artefak baru
                $image = null;
                if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                    $target_dir = "../public/assets/images/";
                    if (!is_dir($target_dir)) {
                        mkdir($target_dir, 0777, true);
                    }
                    $image_name = uniqid() . '_' . basename($_FILES["image"]["name"]);
                    $target_file = $target_dir . $image_name;
                    $image_file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
                    $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
                    $max_size = 2000000; // 2MB

                    if ($_FILES['image']['size'] > $max_size) {
                        throw new Exception("Gambar terlalu besar, maksimal 2MB.");
                    }
                    if (!in_array($image_file_type, $allowed_types)) {
                        throw new Exception("Hanya file JPG, JPEG, PNG, atau GIF yang diizinkan.");
                    }
                    if (!move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                        throw new Exception("Gagal unggah gambar, periksa izin direktori.");
                    }
                    $image = $image_name;
                }

                $sql = "UPDATE products SET name = ?, description = ?, price = ?, stock = ?, category_id = ?";
                if ($image) {
                    $sql .= ", image = ?";
                }
                $sql .= " WHERE id = ?";
                $stmt = $pdo->prepare($sql);
                $params = [$name, $description, $price, $stock, $category_id];
                if ($image) {
                    $params[] = $image;
                }
                $params[] = $id;
                $stmt->execute($params);
                break;

            case 'customers':
                $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
                $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
                $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
                $address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_STRING);

                $stmt = $pdo->prepare("UPDATE customers SET name = ?, email = ?, phone = ?, address = ? WHERE id = ?");
                $stmt->execute([$name, $email, $phone, $address, $id]);
                break;

            case 'categories':
                $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
                $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);

                $stmt = $pdo->prepare("UPDATE categories SET name = ?, description = ? WHERE id = ?");
                $stmt->execute([$name, $description, $id]);
                break;

            case 'admins':
                $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
                $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
                $password = !empty($_POST['password']) ? password_hash($_POST['password'], PASSWORD_DEFAULT) : null;

                if ($password) {
                    $stmt = $pdo->prepare("UPDATE admins SET name = ?, email = ?, password = ? WHERE id = ?");
                    $stmt->execute([$name, $email, $password, $id]);
                } else {
                    $stmt = $pdo->prepare("UPDATE admins SET name = ?, email = ? WHERE id = ?");
                    $stmt->execute([$name, $email, $id]);
                }
                break;
        }

        $pdo->commit();
        logAdminActivity($pdo, $adminId, 'edited_data', "Tabel: $table, ID: $id");
        $_SESSION['message'] = ['type' => 'success', 'text' => 'Data berhasil diubah!'];
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Gagal mengubah data: ' . $e->getMessage()];
    }
    header('Location: data_admin.php');
    exit();
}

// Proses hapus data – Mantra hapus, tapi hati-hati!
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_data'])) {
    $table = filter_input(INPUT_POST, 'table', FILTER_SANITIZE_STRING);
    $id = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT);
    $csrf_token = $_POST['csrf_token'] ?? '';

    if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $csrf_token)) {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Validasi token CSRF gagal.'];
        header('Location: data_admin.php');
        exit();
    }

    $allowed_tables = ['products', 'customers', 'categories', 'admins'];
    if (!in_array($table, $allowed_tables)) {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Tabel tidak valid.'];
        header('Location: data_admin.php');
        exit();
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM $table WHERE id = ?");
        $stmt->execute([$id]);
        logAdminActivity($pdo, $adminId, 'deleted_data', "Tabel: $table, ID: $id");
        $_SESSION['message'] = ['type' => 'success', 'text' => 'Data berhasil dihapus!'];
    } catch (Exception $e) {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Gagal menghapus data: ' . $e->getMessage()];
    }
    header('Location: data_admin.php');
    exit();
}

// Proses tambah data – Mantra cipta baru
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_data'])) {
    $table = filter_input(INPUT_POST, 'table', FILTER_SANITIZE_STRING);
    $csrf_token = $_POST['csrf_token'] ?? '';

    if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $csrf_token)) {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Validasi token CSRF gagal.'];
        header('Location: data_admin.php');
        exit();
    }

    $allowed_tables = ['products', 'customers', 'categories', 'admins'];
    if (!in_array($table, $allowed_tables)) {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Tabel tidak valid.'];
        header('Location: data_admin.php');
        exit();
    }

    try {
        $pdo->beginTransaction();

        switch ($table) {
            case 'products':
                $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
                $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
                $price = filter_input(INPUT_POST, 'price', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                $stock = filter_input(INPUT_POST, 'stock', FILTER_SANITIZE_NUMBER_INT);
                $category_id = filter_input(INPUT_POST, 'category_id', FILTER_SANITIZE_NUMBER_INT);

                $image = '';
                if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                    $target_dir = "../public/assets/images/";
                    if (!is_dir($target_dir)) {
                        mkdir($target_dir, 0777, true);
                    }
                    $image_name = uniqid() . '_' . basename($_FILES["image"]["name"]);
                    $target_file = $target_dir . $image_name;
                    $image_file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
                    $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
                    $max_size = 2000000; // 2MB

                    if ($_FILES['image']['size'] > $max_size) {
                        throw new Exception("Gambar terlalu besar, maksimal 2MB.");
                    }
                    if (!in_array($image_file_type, $allowed_types)) {
                        throw new Exception("Hanya file JPG, JPEG, PNG, atau GIF yang diizinkan.");
                    }
                    if (!move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                        throw new Exception("Gagal unggah gambar, periksa izin direktori.");
                    }
                    $image = $image_name;
                }

                $stmt = $pdo->prepare("INSERT INTO products (name, description, price, stock, category_id, image) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $description, $price, $stock, $category_id, $image]);
                break;

            case 'customers':
                $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
                $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
                $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
                $address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_STRING);

                $stmt = $pdo->prepare("INSERT INTO customers (name, email, phone, address) VALUES (?, ?, ?, ?)");
                $stmt->execute([$name, $email, $phone, $address]);
                break;

            case 'categories':
                $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
                $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);

                $stmt = $pdo->prepare("INSERT INTO categories (name, description) VALUES (?, ?)");
                $stmt->execute([$name, $description]);
                break;

            case 'admins':
                $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
                $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
                $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

                $stmt = $pdo->prepare("INSERT INTO admins (name, email, password) VALUES (?, ?, ?)");
                $stmt->execute([$name, $email, $password]);
                break;
        }

        $pdo->commit();
        logAdminActivity($pdo, $adminId, 'added_data', "Tabel: $table");
        $_SESSION['message'] = ['type' => 'success', 'text' => 'Data berhasil ditambahkan!'];
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Gagal menambahkan data: ' . $e->getMessage()];
    }
    header('Location: data_admin.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Data Admin - Sirkus Kerajaan</title>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/5/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
  <link href="https://fonts.googleapis.com/css2?family=MedievalSharp&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../public/assets/css/public.css">
  <link rel="stylesheet" href="../public/assets/css/circus-footer.css">
  <script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
  <style>
    body {
      background: url('../public/assets/images/starbg.jpeg') no-repeat center/cover;
      font-family: 'MedievalSharp', cursive;
      color: var(--hunyadi-yellow);
    }
    .w3-card {
      background: rgba(0, 0, 0, 0.85);
      border: 2px solid var(--sienna);
      box-shadow: 0 0 20px var(--orange-crayola);
    }
    .w3-bar {
      background: linear-gradient(45deg, var(--sienna), var(--sandy-brown));
    }
    .w3-bar-item:hover {
      background: var(--orange-crayola);
      transform: scale(1.05);
    }
    .chart-container {
      max-width: 600px;
      margin: 0 auto;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      background: rgba(0, 0, 0, 0.6);
      border: 1px solid var(--sienna);
    }
    th, td {
      padding: 10px;
      text-align: left;
      color: var(--hunyadi-yellow);
      border-bottom: 1px solid var(--sienna);
    }
    th {
      background: linear-gradient(45deg, var(--sienna), var(--sandy-brown));
    }
    input, select, textarea, button {
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid var(--sienna);
      color: var(--hunyadi-yellow);
      padding: 8px;
      border-radius: 8px;
      transition: 0.3s ease;
    }
    input:focus, select:focus, textarea:focus {
      outline: none;
      border-color: var(--orange-crayola);
      box-shadow: 0 0 8px rgba(245, 133, 73, 0.5);
    }
    button {
      background: linear-gradient(45deg, var(--sienna), var(--orange-crayola));
      cursor: pointer;
    }
    button:hover {
      background: linear-gradient(45deg, var(--orange-crayola), var(--sienna));
      transform: scale(1.05);
    }
    .card {
      margin: 20px 0;
      padding: 15px;
      border: 2px dashed var(--sandy-brown);
      background: rgba(0, 0, 0, 0.7);
      font-family: 'MedievalSharp', cursive;
      color: var(--hunyadi-yellow);
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
      transition: 0.3s ease;
    }
    .card:hover {
      transform: translateY(-5px);
      background: rgba(86, 42, 14, 0.8);
    }
    #editModal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background: rgba(0, 0, 0, 0.7);
    }
    #editModal .modal-content {
      background: rgba(0, 0, 0, 0.85);
      margin: 15% auto;
      padding: 20px;
      border: 2px solid var(--sienna);
      width: 80%;
      max-width: 600px;
      box-shadow: 0 0 20px var(--orange-crayola);
    }
    .close {
      color: var(--hunyadi-yellow);
      float: right;
      font-size: 28px;
      font-weight: bold;
    }
    .close:hover {
      color: var(--orange-crayola);
      cursor: pointer;
    }

    /* CSS untuk tombol Edit – Seperti tombol Hapus tapi dengan warna berbeda */
    .edit-button {
      background: linear-gradient(45deg, #d4a017, #f5c518); /* Warna kuning keemasan */
      color: #000; /* Teks hitam untuk kontras */
      padding: 5px 10px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 14px;
      transition: transform 0.3s ease, background 0.3s ease;
    }
    .edit-button:hover {
      background: linear-gradient(45deg, #f5c518, #d4a017); /* Balik gradien saat hover */
      transform: scale(1.05);
    }
  </style>
</head>
<body>

  <!-- Particles container – Bintang-bintang kerajaan berkilau -->
  <div id="particles-js" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: -1;"></div>

  <!-- Sidebar – Pintu samping kerajaan -->
  <div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none;z-index:5" id="mySidebar">
    <button class="w3-bar-item w3-button w3-large" onclick="w3_close()">Tutup &times;</button>
    <a href="dashboard.php" class="w3-bar-item w3-button">Dashboard</a>
    <a href="order.php" class="w3-bar-item w3-button">Transaksi</a>
    <a href="data_admin.php" class="w3-bar-item w3-button">Master Data</a>
    <a href="logout.php" class="w3-bar-item w3-button">Logout</a>
  </div>

  <!-- Overlay – Tirai gelap saat sidebar terbuka -->
  <div class="w3-overlay w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" id="myOverlay"></div>

  <!-- Main Content – Arena utama kerajaan -->
  <div class="w3-main" id="mainContent">

    <!-- Top Bar – Mahkota halaman -->
    <div class="w3-top">
      <div class="w3-bar w3-card">
        <button class="w3-bar-item w3-button w3-large" onclick="w3_open()">&#9776;</button>
        <div class="w3-bar-item w3-wide">Sirkus Kerajaan - Master Data</div>
      </div>
    </div>

    <!-- Dashboard Section – Papan kendali raja -->
    <div class="w3-container w3-padding-64" style="margin-top: 50px;">

      <!-- Summary Cards – Kartu harta karun -->
      <div class="w3-row-padding">
        <div class="w3-col m3">
          <div class="w3-card w3-padding w3-center">
            <h3><?= count($products) ?></h3>
            <p>Produk</p>
          </div>
        </div>
        <div class="w3-col m3">
          <div class="w3-card w3-padding w3-center">
            <h3><?= count($customers) ?></h3>
            <p>Pelanggan</p>
          </div>
        </div>
        <div class="w3-col m3">
          <div class="w3-card w3-padding w3-center">
            <h3><?= count($categories) ?></h3>
            <p>Kategori</p>
          </div>
        </div>
        <div class="w3-col m3">
          <div class="w3-card w3-padding w3-center">
            <h3><?= count($admins) ?></h3>
            <p>Admin</p>
          </div>
        </div>
      </div>

      <!-- Chart Section – Peta pendapatan kerajaan (opsional, tapi ditambahkan untuk kemiripan) -->
      <div class="w3-row-padding w3-margin-top">
        <div class="w3-col s12">
          <div class="w3-card chart-container">
            <canvas id="myChart"></canvas>
          </div>
        </div>
      </div>

      <!-- Products Section – Daftar produk kerajaan -->
      <div class="w3-container w3-margin-top card">
        <h2>Produk</h2>
        <?php if (empty($products)): ?>
          <p>Tidak ada produk.</p>
        <?php else: ?>
          <table class="w3-table w3-bordered">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Deskripsi</th>
                <th>Kategori</th>
                <th>Harga</th>
                <th>Stok</th>
                <th>Gambar</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($products as $product): ?>
                <tr>
                  <td><?= htmlspecialchars($product['product_id']) ?></td>
                  <td><?= htmlspecialchars($product['product_name']) ?></td>
                  <td><?= htmlspecialchars($product['description']) ?></td>
                  <td><?= htmlspecialchars($product['category_name']) ?></td>
                  <td>Rp <?= number_format($product['price'], 0, ',', '.') ?></td>
                  <td><?= htmlspecialchars($product['stock']) ?></td>
                  <td><img src="../public/assets/images/<?= htmlspecialchars($product['image']) ?>" alt="Produk" style="width:50px;"></td>
                  <td>
                    <a href="data_edit.php?table=products&id=<?= htmlspecialchars($product['product_id']) ?>" class="edit-button">Edit</a>
                    <form method="POST" class="w3-inline">
                      <input type="hidden" name="delete_data" value="1">
                      <input type="hidden" name="table" value="products">
                      <input type="hidden" name="id" value="<?= htmlspecialchars($product['product_id']) ?>">
                      <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                      <button type="submit" class="w3-button w3-red w3-small">Hapus</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
        <!-- Form Tambah Produk -->
        <h3>Tambah Produk Baru</h3>
        <form method="POST" enctype="multipart/form-data">
          <input type="hidden" name="add_data" value="1">
          <input type="hidden" name="table" value="products">
          <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
          <div class="mb-4">
            <label>Nama:</label>
            <input type="text" name="name" required>
          </div>
          <div class="mb-4">
            <label>Deskripsi:</label>
            <textarea name="description" required></textarea>
          </div>
          <div class="mb-4">
            <label>Harga:</label>
            <input type="number" name="price" required>
          </div>
          <div class="mb-4">
            <label>Stok:</label>
            <input type="number" name="stock" required>
          </div>
          <div class="mb-4">
            <label>Kategori:</label>
            <select name="category_id" required>
              <?php foreach ($categories as $cat): ?>
                <option value="<?= $cat['category_id'] ?>"><?= htmlspecialchars($cat['category_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-4">
            <label>Gambar:</label>
            <input type="file" name="image">
          </div>
          <button type="submit">Tambah</button>
        </form>
      </div>

      <!-- Customers Section – Daftar pelanggan setia -->
      <div class="w3-container w3-margin-top card">
        <h2>Pelanggan</h2>
        <?php if (empty($customers)): ?>
          <p>Tidak ada pelanggan.</p>
        <?php else: ?>
          <table class="w3-table w3-bordered">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Telepon</th>
                <th>Alamat</th>
                <th>Total Pesanan</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($customers as $customer): ?>
                <tr>
                  <td><?= htmlspecialchars($customer['customer_id']) ?></td>
                  <td><?= htmlspecialchars($customer['name']) ?></td>
                  <td><?= htmlspecialchars($customer['email']) ?></td>
                  <td><?= htmlspecialchars($customer['phone']) ?></td>
                  <td><?= htmlspecialchars($customer['address']) ?></td>
                  <td><?= htmlspecialchars($customer['total_orders'] ?? 0) ?></td>
                  <td>
                    <a href="data_edit.php?table=customers&id=<?= htmlspecialchars($customer['customer_id']) ?>" class="edit-button">Edit</a>
                    <form method="POST" class="w3-inline">
                      <input type="hidden" name="delete_data" value="1">
                      <input type="hidden" name="table" value="customers">
                      <input type="hidden" name="id" value="<?= htmlspecialchars($customer['customer_id']) ?>">
                      <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                      <button type="submit" class="w3-button w3-red w3-small">Hapus</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
        <!-- Form Tambah Pelanggan -->
        <h3>Tambah Pelanggan Baru</h3>
        <form method="POST">
          <input type="hidden" name="add_data" value="1">
          <input type="hidden" name="table" value="customers">
          <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
          <div class="mb-4">
            <label>Nama:</label>
            <input type="text" name="name" required>
          </div>
          <div class="mb-4">
            <label>Email:</label>
            <input type="email" name="email" required>
          </div>
          <div class="mb-4">
            <label>Telepon:</label>
            <input type="text" name="phone">
          </div>
          <div class="mb-4">
            <label>Alamat:</label>
            <textarea name="address"></textarea>
          </div>
          <button type="submit">Tambah</button>
        </form>
      </div>

      <!-- Categories Section – Daftar kategori arena -->
      <div class="w3-container w3-margin-top card">
        <h2>Kategori</h2>
        <?php if (empty($categories)): ?>
          <p>Tidak ada kategori.</p>
        <?php else: ?>
          <table class="w3-table w3-bordered">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Deskripsi</th>
                <th>Total Produk</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($categories as $category): ?>
                <tr>
                  <td><?= htmlspecialchars($category['category_id']) ?></td>
                  <td><?= htmlspecialchars($category['category_name']) ?></td>
                  <td><?= htmlspecialchars($category['description']) ?></td>
                  <td><?= htmlspecialchars($category['total_products'] ?? 0) ?></td>
                  <td>
                    <a href="data_edit.php?table=categories&id=<?= htmlspecialchars($category['category_id']) ?>" class="edit-button">Edit</a>
                    <form method="POST" class="w3-inline">
                      <input type="hidden" name="delete_data" value="1">
                      <input type="hidden" name="table" value="categories">
                      <input type="hidden" name="id" value="<?= htmlspecialchars($category['category_id']) ?>">
                      <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                      <button type="submit" class="w3-button w3-red w3-small">Hapus</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
        <!-- Form Tambah Kategori -->
        <h3>Tambah Kategori Baru</h3>
        <form method="POST">
          <input type="hidden" name="add_data" value="1">
          <input type="hidden" name="table" value="categories">
          <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
          <div class="mb-4">
            <label>Nama:</label>
            <input type="text" name="name" required>
          </div>
          <div class="mb-4">
            <label>Deskripsi:</label>
            <textarea name="description" required></textarea>
          </div>
          <button type="submit">Tambah</button>
        </form>
      </div>

      <!-- Admins Section – Daftar penjaga kerajaan -->
      <div class="w3-container w3-margin-top card">
        <h2>Admin</h2>
        <?php if (empty($admins)): ?>
          <p>Tidak ada admin.</p>
        <?php else: ?>
          <table class="w3-table w3-bordered">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($admins as $admin): ?>
                <tr>
                  <td><?= htmlspecialchars($admin['admin_id']) ?></td>
                  <td><?= htmlspecialchars($admin['name']) ?></td>
                  <td><?= htmlspecialchars($admin['email']) ?></td>
                  <td>
                    <a href="data_edit.php?table=admins&id=<?= htmlspecialchars($admin['admin_id']) ?>" class="edit-button">Edit</a>
                    <form method="POST" class="w3-inline">
                      <input type="hidden" name="delete_data" value="1">
                      <input type="hidden" name="table" value="admins">
                      <input type="hidden" name="id" value="<?= htmlspecialchars($admin['admin_id']) ?>">
                      <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                      <button type="submit" class="w3-button w3-red w3-small">Hapus</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
        <!-- Form Tambah Admin -->
        <h3>Tambah Admin Baru</h3>
        <form method="POST">
          <input type="hidden" name="add_data" value="1">
          <input type="hidden" name="table" value="admins">
          <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
          <div class="mb-4">
            <label>Nama:</label>
            <input type="text" name="name" required>
          </div>
          <div class="mb-4">
            <label>Email:</label>
            <input type="email" name="email" required>
          </div>
          <div class="mb-4">
            <label>Password:</label>
            <input type="password" name="password" required>
          </div>
          <button type="submit">Tambah</button>
        </form>
      </div>

    </div>


   <footer class="w3-container w3-footer w3-center" style="padding:32px">
    <a href="https://github.com/cintaaisyahputri" class="w3-button w3-margin-bottom"><i class="fa fa-arrow-up w3-margin-right"></i>To the top</a>
    <p>Powered by the Grand Steampunk Circus Emporium
        MADE BY CINTA AISYAH PUTRI XI RPL 1
    </p>
</footer>

  </div>

  <!-- Edit Modal – Jendela ajaib untuk ubah data (kini tidak lagi digunakan karena tautan) -->
  <div id="editModal" class="w3-modal" style="display: none;">
    <div class="modal-content w3-card">
      <span class="close" onclick="closeEditModal()">&times;</span>
      <h2>Edit Data</h2>
      <form id="editForm" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="edit_data" value="1">
        <input type="hidden" name="table" id="editTable">
        <input type="hidden" name="id" id="editId">
        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
        <div id="modalFields"></div>
        <button type="submit">Simpan Perubahan</button>
      </form>
    </div>
  </div>

  <script>
    // Tampilkan pesan dari session jika ada
    <?php if (isset($_SESSION['message'])): ?>
      Swal.fire({
        title: '<?= $_SESSION['message']['type'] === 'success' ? 'Success' : 'Error' ?>',
        text: '<?= $_SESSION['message']['text'] ?>',
        icon: '<?= $_SESSION['message']['type'] ?>'
      });
      <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    // Sidebar toggle – Buka tutup gerbang samping
    function w3_open() {
      document.getElementById("mySidebar").style.display = "block";
      document.getElementById("myOverlay").style.display = "block";
    }
    function w3_close() {
      document.getElementById("mySidebar").style.display = "none";
      document.getElementById("myOverlay").style.display = "none";
    }

    // Particles.js configuration – Bintang-bintang menari
    particlesJS("particles-js", {
      particles: {
        number: { value: 80, density: { enable: true, value_area: 800 } },
        color: { value: "#f58549" },
        shape: { type: "star", stroke: { width: 0, color: "#000000" } },
        opacity: { value: 0.5, random: false },
        size: { value: 3, random: true },
        line_linked: { enable: true, distance: 150, color: "#f58549", opacity: 0.4, width: 1 },
        move: { enable: true, speed: 6, direction: "none", random: false }
      },
      interactivity: {
        detect_on: "canvas",
        events: { onhover: { enable: true, mode: "repulse" }, onclick: { enable: true, mode: "push" } },
        modes: { repulse: { distance: 100, duration: 0.4 }, push: { particles_nb: 4 } }
      }
    });

    // Confetti effect on load – Hujan bintang saat halaman dimuat
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#f58549', '#f2a65a', '#eec170']
    });

    // Chart.js configuration – Peta data kerajaan (contoh data)
    const ctx = document.getElementById('myChart').getContext('2d');
    const myChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Produk', 'Pelanggan', 'Kategori', 'Admin'],
        datasets: [{
          label: 'Jumlah Data',
          data: [<?= count($products) ?>, <?= count($customers) ?>, <?= count($categories) ?>, <?= count($admins) ?>],
          backgroundColor: '#f58549',
          borderColor: '#f58549',
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          y: { beginAtZero: true }
        }
      }
    });

    // Close Edit Modal – Tutup jendela ajaib (kini tidak digunakan)
    function closeEditModal() {
      document.getElementById('editModal').style.display = 'none';
    }

    // Tutup modal jika klik luar – Seperti tirai tutup
    window.onclick = function(event) {
      const modal = document.getElementById('editModal');
      if (event.target == modal) {
        closeEditModal();
      }
    }

    // SweetAlert untuk konfirmasi tambahan – Suara herald
    document.querySelectorAll('form').forEach(form => {
      form.addEventListener('submit', function(event) {
        if (form.querySelector('input[name="delete_data"]')) { // Hanya untuk hapus
          event.preventDefault();
          Swal.fire({
            title: 'Konfirmasi Mantra?',
            text: 'Yakin hapus harta ini?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Ya, Laksanakan!',
            cancelButtonText: 'Batal'
          }).then((result) => {
            if (result.isConfirmed) {
              form.submit();
            }
          });
        } else if (form.querySelector('input[name="add_data"]')) {
          event.preventDefault();
          Swal.fire({
            title: 'Konfirmasi Mantra?',
            text: 'Yakin tambah harta ini?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Ya, Laksanakan!',
            cancelButtonText: 'Batal'
          }).then((result) => {
            if (result.isConfirmed) {
              form.submit();
            }
          });
        }
      });
    });

    // Animasi tambahan – Fade in bertahap untuk setiap card
    document.addEventListener('DOMContentLoaded', () => {
      const cards = document.querySelectorAll('.card');
      cards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.2}s`;
        card.classList.add('animate__fadeInUp');
      });
    });

    // Log out timer – Jika idle, ingatkan seperti pelayan istana
    let idleTimer = setTimeout(() => {
      Swal.fire({
        title: 'Waktu Istirahat?',
        text: 'Kembali ke dashboard atau lanjut?',
        icon: 'info',
        showCancelButton: true,
        confirmButtonText: 'Lanjut Kelola',
        cancelButtonText: 'Kembali Dashboard'
      }).then((result) => {
        if (!result.isConfirmed) {
          window.location.href = 'dashboard.php';
        }
      });
    }, 300000); // 5 menit idle

    document.addEventListener('mousemove', () => clearTimeout(idleTimer));
    document.addEventListener('keydown', () => clearTimeout(idleTimer));

    // Fungsi tambahan untuk export data – Seperti salin gulungan ke PDF (simulasi)
    function exportToPDF(table) {
      Swal.fire({
        title: 'Ekspor ke Gulungan PDF?',
        text: `Data ${table === 'all' ? 'semua' : table} akan dicetak sebagai artefak kerajaan!`,
        icon: 'success',
        confirmButtonText: 'Cetak Sekarang'
      }).then(() => {
        // Simulasi – Di real, gunakan jsPDF
        window.print();
        confetti({
          particleCount: 50,
          spread: 50,
          origin: { y: 0.6 },
          colors: ['#f58549', '#f2a65a', '#eec170']
        });
      });
    }

    // Tambahan: Log aktivitas setiap 1 menit – Pantau raja
    setInterval(() => {
      // Simulasi log, karena PDO tidak bisa langsung di JS
      console.log('Raja masih mengelola harta');
    }, 60000);

    const now = new Date();
    if (now.getHours() === 9 && now.getMinutes() === 0) { 
        title: 'Tugas Harian!',
        text: 'Periksa pesanan dan stok kuda perang hari ini.',
        icon: 'info',
        confirmButtonText: 'Lihat Pesanan'
      }).then((result) => {
        if (result.isConfirmed) {
          window.location.href = 'order.php';
        }
      });
    }

    console.log('Gerbang data admin terbuka – Siap kelola kerajaan, <?= $_SESSION['admin_name'] ?>!');
  </script>
</body>
</html>
<?php ob_end_flush(); ?>