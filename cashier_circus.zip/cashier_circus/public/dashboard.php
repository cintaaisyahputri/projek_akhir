<?php
require '../app/middleware/app.php';


if (!isset($_SESSION['admin_name'])) {
    header('Location: login.php');
    exit();
}

$orders = $pdo->query("SELECT o.id, o.created_at, c.name AS customer_name, p.name AS product_name, op.quantity, o.total_payment, o.status 
                       FROM orders o 
                       JOIN customers c ON o.customer_id = c.id 
                       JOIN order_products op ON o.id = op.order_id 
                       JOIN products p ON op.product_id = p.id")->fetchAll(PDO::FETCH_ASSOC);


$totalOrders = count($orders);
$totalRevenue = array_sum(array_column($orders, 'total_payment'));
$pendingOrders = count(array_filter($orders, function ($order) {
  return $order['status'] == 'pending';
}));
$completedOrders = count(array_filter($orders, function ($order) {
  return $order['status'] == 'completed';
}));
$canceledOrders = count(array_filter($orders, function ($order) {
  return $order['status'] == 'canceled';
}));

$orderStats = $pdo->query("SELECT DATE_FORMAT(created_at, '%Y-%m') AS month, COUNT(*) AS order_count, SUM(total_payment) AS revenue 
                           FROM orders 
                           GROUP BY DATE_FORMAT(created_at, '%Y-%m')
                           ORDER BY month DESC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);
$chartLabels = array_column($orderStats, 'month');
$chartOrderCounts = array_column($orderStats, 'order_count');
$chartRevenue = array_column($orderStats, 'revenue');


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id']) && isset($_POST['status'])) {
  $orderId = filter_input(INPUT_POST, 'order_id', FILTER_SANITIZE_NUMBER_INT);
  $status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_STRING);
  $validStatuses = ['pending', 'in_order', 'completed', 'canceled'];
  if (in_array($status, $validStatuses)) {
    $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->execute([$status, $orderId]);
  } else {
    echo '<script>Swal.fire("Error", "Status tidak valid.", "error");</script>';
  }
  header('Location: dashboard.php');
  exit();
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_order_id'])) {
  $deleteOrderId = filter_input(INPUT_POST, 'delete_order_id', FILTER_SANITIZE_NUMBER_INT);
  $stmt = $pdo->prepare("DELETE FROM orders WHERE id = ?");
  $stmt->execute([$deleteOrderId]);
  echo '<script>Swal.fire("Success", "Pesanan berhasil dihapus!", "success");</script>';
  header('Location: dashboard.php');
  exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Sirkus Kerajaan</title>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/5/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
  <link href="https://fonts.googleapis.com/css2?family=MedievalSharp&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../public/assets/css/public.css">
  <link rel="stylesheet" href="../public/assets/css/circus-footer.css">
  <script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
  <style>
    body {
      background: url('../public/assets/images/starbg.jpeg') no-repeat center/cover;
      font-family: 'MedievalSharp', cursive;
      color: var(--hunyadi-yellow);
    }
    .w3-card {
      background: rgba(0, 0, 0, 0.85);
      border: 2px solid var(--sienna);
      box-shadow: 0 0 20px var(--orange-crayola);
    }
    .w3-bar {
      background: linear-gradient(45deg, var(--sienna), var(--sandy-brown));
    }
    .w3-bar-item:hover {
      background: var(--orange-crayola);
      transform: scale(1.05);
    }
    .chart-container {
      max-width: 600px;
      margin: 20px auto;
      padding: 20px;
      background: rgba(0, 0, 0, 0.7);
      border-radius: 12px;
      border: 1px solid var(--sienna);
    }
  </style>
</head>
<body class="w3-light-grey">

  <div id="particles-js" style="position: fixed; width: 100%; height: 100%; z-index: -1;"></div>


  <div class="w3-bar w3-black w3-hide-small">
    <a href="dashboard.php" class="w3-bar-item w3-button"><i class="fa fa-home"></i> Dashboard</a>
    <a href="order.php" class="w3-bar-item w3-button"><i class="fa fa-shopping-cart"></i> Transaksi</a>
    <a href="data_admin.php" class="w3-bar-item w3-button"><i class="fa fa-database"></i> Master Data</a>
    <a href="logout.php" class="w3-bar-item w3-button w3-right"><i class="fa fa-sign-out"></i> Logout</a>
    <a href="#" class="w3-bar-item w3-button w3-right"><i class="fa fa-search"></i></a>
  </div>


  <nav class="w3-sidebar w3-bar-block w3-black w3-collapse w3-top w3-hide-large" style="z-index:3;width:250px" id="mySidebar">
    <div class="w3-container w3-display-container w3-padding-16">
      <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
      <h3 class="w3-wide"><b>Sirkus Kerajaan</b></h3>
    </div>
    <div class="w3-padding-64 w3-large w3-text-grey" style="font-weight:bold">
      <a href="dashboard.php" class="w3-bar-item w3-button">Dashboard</a>
      <a href="order.php" class="w3-bar-item w3-button">Transaksi</a>
      <a href="data_admin.php" class="w3-bar-item w3-button">Master Data</a>
      <a href="logout.php" class="w3-bar-item w3-button">Logout</a>
    </div>
  </nav>

 
  <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" id="myOverlay"></div>

 
  <div class="w3-main" style="margin-left:250px;margin-top:43px;">
    <header class="w3-container w3-center w3-padding-48 w3-card">
      <h1 class="w3-xxxlarge animate__animated animate__fadeIn"><b>Sirkus Kerajaan Dashboard</b></h1>
      <p class="w3-opacity w3-center"><i>Selamat datang, <?= htmlspecialchars($_SESSION['admin_name']) ?></i></p>
    </header>

  
    <div class="w3-row-padding w3-padding">
      <div class="w3-col l4 m6 w3-margin-bottom">
        <div class="w3-card w3-padding">
          <h3>Total Pesanan</h3>
          <p class="w3-large"><?= $totalOrders ?></p>
        </div>
      </div>
      <div class="w3-col l4 m6 w3-margin-bottom">
        <div class="w3-card w3-padding">
          <h3>Total Pendapatan</h3>
          <p class="w3-large">Rp <?= number_format($totalRevenue, 0, ',', '.') ?></p>
        </div>
      </div>
      <div class="w3-col l4 m6 w3-margin-bottom">
        <div class="w3-card w3-padding">
          <h3>Pesanan Tertunda</h3>
          <p class="w3-large"><?= $pendingOrders ?></p>
        </div>
      </div>
    </div>

   
    <div class="chart-container">
      <canvas id="orderChart"></canvas>
    </div>

   
    <div class="w3-container w3-padding w3-card">
      <h3 class="w3-border-bottom w3-border-light-grey w3-padding-16">Riwayat Pesanan</h3>
      <?php if (empty($orders)): ?>
        <p class="w3-text-grey w3-italic">Belum ada pesanan.</p>
      <?php else: ?>
        <table class="w3-table w3-bordered">
          <thead>
            <tr>
              <th>ID</th>
              <th>Pelanggan</th>
              <th>Produk</th>
              <th>Jumlah</th>
              <th>Tanggal</th>
              <th>Total</th>
              <th>Status</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($orders as $order): ?>
              <tr>
                <td><?= htmlspecialchars($order['id']) ?></td>
                <td><?= htmlspecialchars($order['customer_name']) ?></td>
                <td><?= htmlspecialchars($order['product_name']) ?></td>
                <td><?= htmlspecialchars($order['quantity']) ?></td>
                <td><?= htmlspecialchars(date('d-m-Y', strtotime($order['created_at']))) ?></td>
                <td>Rp <?= htmlspecialchars(number_format($order['total_payment'], 0, ',', '.')) ?></td>
                <td>
                  <span class="w3-tag w3-round <?= $order['status'] == 'completed' ? 'w3-green' : ($order['status'] == 'in_order' ? 'w3-yellow' : 'w3-red') ?>">
                    <?= htmlspecialchars(ucfirst($order['status'])) ?>
                  </span>
                </td>
                <td>
                  <form method="POST" class="w3-inline">
                    <input type="hidden" name="order_id" value="<?= htmlspecialchars($order['id']) ?>">
                    <select name="status" onchange="this.form.submit()" class="w3-select w3-border">
                      <option value="pending" <?= $order['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
                      <option value="in_order" <?= $order['status'] == 'in_order' ? 'selected' : '' ?>>Dalam Proses</option>
                      <option value="completed" <?= $order['status'] == 'completed' ? 'selected' : '' ?>>Selesai</option>
                      <option value="canceled" <?= $order['status'] == 'canceled' ? 'selected' : '' ?>>Dibatalkan</option>
                    </select>
                  </form>
                  <form method="POST" class="w3-inline">
                    <input type="hidden" name="delete_order_id" value="<?= htmlspecialchars($order['id']) ?>">
                    <button type="submit" class="w3-button w3-red w3-small">Hapus</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>


<footer class="w3-container w3-footer w3-center" style="padding:32px">
    <a href="https://github.com/cintaaisyahputri" class="w3-button w3-margin-bottom"><i class="fa fa-arrow-up w3-margin-right"></i>To the top</a>
    <p>Powered by the Grand Steampunk Circus Emporium
        MADE BY CINTA AISYAH PUTRI XI RPL 1
    </p>
</footer>

  <script>
  
    function w3_open() {
      document.getElementById("mySidebar").style.display = "block";
      document.getElementById("myOverlay").style.display = "block";
    }
    function w3_close() {
      document.getElementById("mySidebar").style.display = "none";
      document.getElementById("myOverlay").style.display = "none";
    }

 
    particlesJS("particles-js", {
      particles: {
        number: { value: 80, density: { enable: true, value_area: 800 } },
        color: { value: "#f58549" },
        shape: { type: "star", stroke: { width: 0, color: "#000000" } },
        opacity: { value: 0.5, random: false },
        size: { value: 3, random: true },
        line_linked: { enable: true, distance: 150, color: "#f58549", opacity: 0.4, width: 1 },
        move: { enable: true, speed: 6, direction: "none", random: false }
      },
      interactivity: {
        detect_on: "canvas",
        events: { onhover: { enable: true, mode: "repulse" }, onclick: { enable: true, mode: "push" } },
        modes: { repulse: { distance: 100, duration: 0.4 }, push: { particles_nb: 4 } }
      }
    });


    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#f58549', '#f2a65a', '#eec170']
    });

  
    ```chartjs
    {
      type: 'bar',
      data: {
        labels: <?= json_encode($chartLabels) ?>,
        datasets: [
          {
            label: 'Jumlah Pesanan',
            data: <?= json_encode($chartOrderCounts) ?>,
            backgroundColor: '#f58549',
            borderColor: '#f58549',
            borderWidth: 1
          },
          {
            label: 'Pendapatan (Rp)',
            data: <?= json_encode($chartRevenue) ?>,
            backgroundColor: '#f2a65a',
            borderColor: '#f2a65a',
            borderWidth: 1
          }
        ]
      },
      options: {
        scales: {
          y: { beginAtZero: true }
        },
        plugins: {
          legend: { display: true, position: 'top' }
        }
      }
    }