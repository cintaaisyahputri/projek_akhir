<?php 
session_start();
include '../app/middleware/app.php';

// Check login status
function checkLogin() {
    if (!isset($_SESSION['admin_name'])) {
        header("Location: ../login.php");
        exit;
    }
}
checkLogin();

// Display error messages
function displayErrorMessage() {
    if (isset($_SESSION['login_error'])) {
        echo '<div class="w3-panel w3-red w3-padding">' . htmlspecialchars($_SESSION['login_error']) . '</div>';
        unset($_SESSION['login_error']);
    }
}
displayErrorMessage();

// Initialize CSRF token
function initCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
}
initCSRFToken();

// Fetch data from database
function fetchData($pdo, $query) {
    try {
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log("Error fetching data: " . $e->getMessage());
        return [];
    }
}

// Process order
function processOrder($pdo) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['admin_id']) && isset($_POST['customer_id'])) {
        if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            echo json_encode(['status' => 'error', 'message' => 'Validasi token CSRF gagal']);
            exit;
        }

        $adminId = filter_input(INPUT_POST, 'admin_id', FILTER_SANITIZE_NUMBER_INT);
        $customerId = filter_input(INPUT_POST, 'customer_id', FILTER_SANITIZE_NUMBER_INT);
        $orderedProducts = json_decode($_POST['ordered_products'], true);

        if (!is_array($orderedProducts) || empty($orderedProducts)) {
            echo json_encode(['status' => 'error', 'message' => 'Tidak ada produk yang dipilih']);
            exit;
        }

        $totalPayment = array_reduce($orderedProducts, function ($carry, $product) {
            return $carry + ($product['price'] * $product['quantity']);
        }, 0);

        $totalProduct = array_reduce($orderedProducts, function ($carry, $product) {
            return $carry + $product['quantity'];
        }, 0);

        try {
            $pdo->beginTransaction();

            // Validate stock
            foreach ($orderedProducts as $product) {
                $stmt = $pdo->prepare("SELECT stock FROM products WHERE id = ?");
                $stmt->execute([$product['id']]);
                $stock = $stmt->fetchColumn();
                if ($stock < $product['quantity']) {
                    throw new Exception("Stok tidak cukup untuk produk: " . $product['name']);
                }
            }

            // Update stock
            foreach ($orderedProducts as $product) {
                $stmt = $pdo->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
                $stmt->execute([$product['quantity'], $product['id']]);
            }

            // Insert order
            $stmt = $pdo->prepare("INSERT INTO orders (admin_id, customer_id, total_payment, total_product) VALUES (?, ?, ?, ?)");
            $stmt->execute([$adminId, $customerId, $totalPayment, $totalProduct]);
            $orderId = $pdo->lastInsertId();

            // Insert order products
            $stmt = $pdo->prepare("INSERT INTO order_products (order_id, product_id, quantity, total_price) VALUES (?, ?, ?, ?)");
            foreach ($orderedProducts as $product) {
                $itemTotalPrice = $product['price'] * $product['quantity'];
                $stmt->execute([$orderId, $product['id'], $product['quantity'], $itemTotalPrice]);
            }

            $pdo->commit();
            echo json_encode(['status' => 'success', 'message' => 'Pesanan berhasil diproses!']);
        } catch (Exception $e) {
            $pdo->rollBack();
            echo json_encode(['status' => 'error', 'message' => 'Gagal memproses pesanan: ' . $e->getMessage()]);
        }
        exit;
    }
}
processOrder($pdo);

// Fetch categories and products
$categories = fetchData($pdo, "SELECT * FROM categories");
$products = fetchData($pdo, "SELECT p.*, c.name AS category_name FROM products p JOIN categories c ON p.category_id = c.id WHERE p.stock > 0");
$customers = fetchData($pdo, "SELECT id, name FROM customers");
$admins = fetchData($pdo, "SELECT id, name FROM admins");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Transaksi Sirkus Kerajaan</title>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/5/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
  <link href="https://fonts.googleapis.com/css2?family=MedievalSharp&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../public/assets/css/public.css">
  <link rel="stylesheet" href="../public/assets/css/circus-footer.css">
  <script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    body {
      background: url('../public/assets/images/starbg.jpeg') no-repeat center/cover;
      font-family: 'MedievalSharp', cursive;
      color: var(--hunyadi-yellow);
      position: relative;
      overflow-x: hidden;
    }
    .w3-card {
      background: rgba(0, 0, 0, 0.85);
      border: 2px solid var(--sienna);
      box-shadow: 0 0 20px var(--orange-crayola);
    }
    .w3-bar {
      background: linear-gradient(45deg, var(--sienna), --sandy-brown);
    }
    .w3-bar-item:hover {
      background: var(--orange-crayola);
      transform: scale(1.05);
    }
    .product-card img {
      width: 100%;
      height: 200px;
      object-fit: cover;
      border-radius: 8px;
    }
    .search-bar {
      max-width: 400px;
      margin: 20px auto;
    }
    .logo img {
      max-width: 150px;
      height: auto;
      display: block;
      margin: 0 auto;
    }
    .marquee-container {
      width: 100%;
      overflow: hidden;
      background: rgba(86, 42, 14, 0.7);
      border-top: 2px solid var(--sienna);
      border-bottom: 2px solid var(--sienna);
      margin-bottom: 20px;
    }
    marquee {
      display: flex;
      white-space: nowrap;
    }
    marquee img {
      height: 50px;
      margin-right: 10px;
    }
  </style>
</head>
<body class="w3-light-grey">
  <!-- Particles Background -->
  <div id="particles-js" style="position: fixed; width: 100%; height: 100%; z-index: -1;"></div>

  <!-- Navbar -->
  <div class="w3-bar w3-black w3-hide-small">
    <a href="dashboard.php" class="w3-bar-item w3-button"><i class="fa fa-home"></i> Dashboard</a>
    <a href="order.php" class="w3-bar-item w3-button"><i class="fa fa-shopping-cart"></i> Transaksi</a>
    <a href="data_admin.php" class="w3-bar-item w3-button"><i class="fa fa-database"></i> Master Data</a>
    <a href="logout.php" class="w3-bar-item w3-button w3-right"><i class="fa fa-sign-out"></i> Logout</a>
    <a href="#" class="w3-bar-item w3-button w3-right"><i class="fa fa-search"></i></a>
  </div>

  <!-- Sidebar for small screens -->
  <nav class="w3-sidebar w3-bar-block w3-black w3-collapse w3-top w3-hide-large" style="z-index:3;width:250px" id="mySidebar">
    <div class="w3-container w3-display-container w3-padding-16">
      <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
      <h3 class="w3-wide"><b>Sirkus Kerajaan</b></h3>
    </div>
    <div class="w3-padding-64 w3-large w3-text-grey" style="font-weight:bold">
      <a href="dashboard.php" class="w3-bar-item w3-button">Dashboard</a>
      <a href="order.php" class="w3-bar-item w3-button">Transaksi</a>
      <a href="data_admin.php" class="w3-bar-item w3-button">Master Data</a>
      <a href="logout.php" class="w3-bar-item w3-button">Logout</a>
    </div>
  </nav>

  <!-- Overlay for sidebar -->
  <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" id="myOverlay"></div>

  <!-- Main Content -->
  <div class="w3-main" style="margin-left:250px;margin-right:40px">
    <header class="w3-container w3-center w3-padding-32">
      <h1 class="w3-xxxlarge animate__animated animate__fadeIn"><b>Transaksi Sirkus Kerajaan</b></h1>
     <h1 class="welcome-text">Selamat Datang, CINTA!</h1>
    </header>

    <!-- Order Form -->
    <div class="w3-container w3-padding w3-card">
      <h3 class="w3-border-bottom w3-border-light-grey w3-padding-16">Buat Pesanan Baru</h3>
      <form id="orderForm" class="w3-container">
        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
        <div class="w3-row-padding">
          <div class="w3-half">
            <label>Pilih Admin</label>
            <select name="admin_id" id="admin_id" class="w3-select w3-border" required>
              <?php foreach ($admins as $admin): ?>
                <option value="<?= htmlspecialchars($admin['id']) ?>" <?= $admin['id'] == ($_SESSION['admin_id'] ?? '') ? 'selected' : '' ?>>
                  <?= htmlspecialchars($admin['name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="w3-half">
            <label>Pilih Pelanggan</label>
            <select name="customer_id" id="customer_id" class="w3-select w3-border" required>
              <?php foreach ($customers as $customer): ?>
                <option value="<?= htmlspecialchars($customer['id']) ?>">
                  <?= htmlspecialchars($customer['name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <button type="submit" class="w3-button w3-margin-top" style="background: linear-gradient(45deg, #78380c, #c8691c);">Proses Pesanan</button>
      </form>
    </div>

    <!-- Search and Filter -->
    <div class="w3-container w3-padding w3-card">
      <div class="search-bar w3-row-padding">
        <div class="w3-half">
          <input type="text" id="searchInput" class="w3-input w3-border" placeholder="Cari Produk...">
        </div>
        <div class="w3-half">
          <select id="categoryFilter" class="w3-select w3-border">
            <option value="">Semua Kategori</option>
            <?php foreach ($categories as $category): ?>
              <option value="<?= htmlspecialchars($category['id']) ?>">
                <?= htmlspecialchars($category['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
    </div>

    <!-- Order Summary -->
    <div class="w3-container w3-padding w3-card">
      <h3 class="w3-border-bottom w3-border-light-grey w3-padding-16">Ringkasan Pesanan</h3>
      <div id="orderSummary">
        <p class="w3-text-grey w3-italic">Belum ada produk dipilih.</p>
      </div>
    </div>

    <!-- Products -->
    <div class="w3-row-padding w3-padding">
      <?php foreach ($products as $product): ?>
        <div class="w3-col l3 m6 w3-margin-bottom product-card" 
             data-id="<?= htmlspecialchars($product['id']) ?>" 
             data-name="<?= htmlspecialchars($product['name']) ?>" 
             data-price="<?= htmlspecialchars($product['price']) ?>" 
             data-category="<?= htmlspecialchars($product['category_id']) ?>">
          <div class="w3-card w3-padding">
            <img src="../public/assets/images/<?= htmlspecialchars($product['image'] ?? 'default.jpg') ?>" 
                 alt="<?= htmlspecialchars($product['name']) ?>" 
                 onerror="this.src='../public/assets/images/default.jpg'">
            <h4><?= htmlspecialchars($product['name']) ?></h4>
            <p>Kategori: <?= htmlspecialchars($product['category_name']) ?></p>
            <p>Harga: Rp <?= number_format($product['price'], 0, ',', '.') ?></p>
            <p>Stok: <?= htmlspecialchars($product['stock']) ?></p>
            <input type="number" class="w3-input w3-border product-quantity" min="0" max="<?= htmlspecialchars($product['stock']) ?>" value="0">
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

 <footer class="w3-container w3-footer w3-center" style="padding:32px">
    <a href="https://github.com/cintaaisyahputri" class="w3-button w3-margin-bottom"><i class="fa fa-arrow-up w3-margin-right"></i>To the top</a>
    <p>Powered by the Grand Steampunk Circus Emporium
        MADE BY CINTA AISYAH PUTRI XI RPL 1
    </p>
</footer>

  <script>
    let orderItems = [];

    // Sidebar toggle
    function w3_open() {
      document.getElementById("mySidebar").style.display = "block";
      document.getElementById("myOverlay").style.display = "block";
    }
    function w3_close() {
      document.getElementById("mySidebar").style.display = "none";
      document.getElementById("myOverlay").style.display = "none";
    }

    // Particles.js configuration
    particlesJS("particles-js", {
      particles: {
        number: { value: 80, density: { enable: true, value_area: 800 } },
        color: { value: "#f58549" },
        shape: { type: "star", stroke: { width: 0, color: "#000000" } },
        opacity: { value: 0.5, random: false },
        size: { value: 3, random: true },
        line_linked: { enable: true, distance: 150, color: "#f58549", opacity: 0.4, width: 1 },
        move: { enable: true, speed: 6, direction: "none", random: false }
      },
      interactivity: {
        detect_on: "canvas",
        events: { onhover: { enable: true, mode: "repulse" }, onclick: { enable: true, mode: "push" } },
        modes: { repulse: { distance: 100, duration: 0.4 }, push: { particles_nb: 4 } }
      }
    });

    // Confetti effect on load
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#f58549', '#f2a65a', '#eec170']
    });

    // Product filtering
    const searchInput = document.getElementById('searchInput');
    const categoryFilter = document.getElementById('categoryFilter');
    const productCards = document.querySelectorAll('.product-card');

    function applyFilters() {
      const searchTerm = searchInput.value.toLowerCase();
      const selectedCategory = categoryFilter.value;

      productCards.forEach(card => {
        const name = card.dataset.name.toLowerCase();
        const category = card.dataset.category;
        const matchesSearch = name.includes(searchTerm);
        const matchesCategory = !selectedCategory || category === selectedCategory;
        card.style.display = matchesSearch && matchesCategory ? 'block' : 'none';
      });
    }

    searchInput.addEventListener('input', applyFilters);
    categoryFilter.addEventListener('change', applyFilters);

    // Update order items
    document.querySelectorAll('.product-quantity').forEach(input => {
      input.addEventListener('change', (e) => {
        const productCard = e.target.closest('.product-card');
        updateOrderItems(productCard);
      });
    });

    function updateOrderItems(product) {
      const id = product.dataset.id;
      const name = product.dataset.name;
      const price = parseFloat(product.dataset.price);
      const quantity = parseInt(product.querySelector('.product-quantity').value);

      const idx = orderItems.findIndex(item => item.id === id);
      if (idx !== -1) {
        if (quantity === 0) {
          orderItems.splice(idx, 1);
        } else {
          orderItems[idx].quantity = quantity;
        }
      } else if (quantity > 0) {
        orderItems.push({ id, name, price, quantity });
      }
      updateOrderSummary();
    }

    function updateOrderSummary() {
      const summary = document.getElementById('orderSummary');
      summary.innerHTML = '';
      let total = 0;

      if (orderItems.length === 0) {
        summary.innerHTML = '<p class="w3-text-grey w3-italic">Belum ada produk dipilih.</p>';
      } else {
        let table = `<table class="w3-table w3-bordered">
                      <thead>
                        <tr class="w3-indigo">
                          <th>Produk</th>
                          <th>Jumlah</th>
                          <th>Subtotal</th>
                        </tr>
                      </thead>
                      <tbody>`;
        orderItems.forEach(item => {
          const subtotal = item.price * item.quantity;
          total += subtotal;
          table += `<tr>
                      <td>${item.name}</td>
                      <td>${item.quantity}</td>
                      <td>Rp ${subtotal.toLocaleString('id-ID')}</td>
                    </tr>`;
        });
        table += `</tbody></table>
                  <div class="w3-right w3-margin-top w3-text-indigo">
                    <b>Total: Rp ${total.toLocaleString('id-ID')}</b>
                  </div>`;
        summary.innerHTML = table;
      }
    }

    function resetQuantities() {
      document.querySelectorAll('.product-quantity').forEach(input => input.value = 0);
      orderItems = [];
      updateOrderSummary();
    }

    // Submit order
    document.getElementById('orderForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const adminId = document.getElementById('admin_id').value;
      const customerId = document.getElementById('customer_id').value;

      if (orderItems.length === 0) {
        Swal.fire('Pesanan Kosong!', 'Tambahkan produk terlebih dahulu.', 'warning');
        return;
      }

      const orderData = {
        admin_id: adminId,
        customer_id: customerId,
        ordered_products: JSON.stringify(orderItems),
        csrf_token: document.querySelector('input[name="csrf_token"]').value
      };

      try {
        const response = await fetch(window.location.href, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams(orderData)
        });
        const result = await response.json();
        Swal.fire(result.status === 'success' ? 'Berhasil!' : 'Gagal!', result.message, result.status);
        if (result.status === 'success') {
          orderItems = [];
          updateOrderSummary();
          resetQuantities();
        }
      } catch (error) {
        Swal.fire('Error', 'Terjadi kesalahan saat memproses pesanan.', 'error');
      }
    });
  </script>
</body>
</html>