-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 21, 2025 at 02:03 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_circus`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `last_login`, `created_at`) VALUES
(5, 'arvin', 'arvin@gmail.com', '$2y$10$1qyDWXpvA4dHWpoUtA5xQ.oHn.MWDHV0.8OYo7qv/0wBU0hiQbU7a', NULL, '2025-09-20 21:59:04'),
(11, 'lakeisha', 'lakeisha@gmail.com', '$2y$10$04f8996da763b7a969b1028ee3007569eaf3a635486ddab211d512c85b9df8fb', NULL, '2025-09-20 21:59:04'),
(12, 'fitri', 'fitri@gmail.com', '$2y$10$04f8996da763b7a969b1028ee3007569eaf3a635486ddab211d512c85b9df8fb', NULL, '2025-09-20 21:59:04'),
(17, 'tiara', 'tiara@gmail.com', '$2y$10$g0cktUfo2ICvyfIIN6N6fuije0vZYl1Wx6BdAh1dUYkLk8DF5jTci', NULL, '2025-09-21 18:29:30'),
(18, 'cinta', 'cinta@gmail.com', '$2y$10$D2LMZv3to4goGt7DPSqReeMF5rjkpJAm3rf3TqY4PwXbEkMvHrfPi', NULL, '2025-09-21 18:29:58');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`) VALUES
(1, 'Items', 'Circus-related merchandise and souvenirs'),
(2, 'Tickets', 'Tickets for various circus shows and events'),
(3, 'coba', 'miaw');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `created_at`) VALUES
(1, 'John Doe', 'john.doe@example.com', '555-0101', '123 Medieval Lane, Circus Town', '2025-09-10 13:41:33'),
(2, 'Jane Smith', 'jane.smith@example.com', '555-0102', '456 Steampunk Road, Circus Town', '2025-09-10 13:41:33'),
(3, 'Alice Brown', 'alice.brown@example.com', '555-0103', '789 Old Tent Street, Circus Town', '2025-09-10 13:41:33'),
(4, 'Bob Wilson', 'bob.wilson@example.com', '555-0104', '101 Brass Gear Avenue, Circus Town', '2025-09-10 13:41:33'),
(5, 'Emma Davis', 'emma.davis@example.com', '555-0105', '202 Vintage Circus Way, Circus Town', '2025-09-10 13:41:33'),
(6, 'jamal', 'jamal@gmail.com', '11111111', 'terserah', '2025-09-20 16:27:35');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `total_payment` decimal(10,2) NOT NULL,
  `total_product` int(11) NOT NULL,
  `status` enum('pending','in_order','completed','canceled') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `admin_id`, `customer_id`, `total_payment`, `total_product`, `status`, `created_at`) VALUES
(5, 5, 1, 75.00, 2, 'pending', '2025-09-12 08:11:06'),
(24, 5, 1, 30.00, 1, 'pending', '2025-09-17 12:07:40'),
(26, 5, 1, 55.00, 1, 'pending', '2025-09-17 13:21:41'),
(28, 5, 2, 80.00, 4, 'pending', '2025-09-18 01:09:36');

-- --------------------------------------------------------

--
-- Table structure for table `order_products`
--

CREATE TABLE `order_products` (
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_products`
--

INSERT INTO `order_products` (`order_id`, `product_id`, `quantity`, `total_price`) VALUES
(5, 1, 1, 45.00),
(5, 2, 1, 30.00),
(24, 2, 1, 30.00),
(26, 14, 1, 55.00),
(28, 6, 4, 80.00);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `stock`, `image`, `created_at`) VALUES
(1, 1, 'Steampunk Top Hat tes', 'A vintage top hat with gears and brass accents', 45.00, 25, '68cf4cbd9772a_68cf4c1dc0d6d_star.png', '2025-09-10 13:41:33'),
(2, 1, 'Medieval Jester Mask', 'Handcrafted mask with bells and velvet', 30.00, 76, '68cf4cb3431fb_68cf4c1dc0d6d_star.png', '2025-09-10 13:41:33'),
(3, 1, 'Circus Poster', 'Old-fashioned circus poster with vibrant colors', 15.00, 200, '68cf4cabbc703_68cf4be5d17d4_star.png', '2025-09-10 13:41:33'),
(4, 1, 'Brass Compass', 'Steampunk-inspired navigation tool', 25.00, 80, '68cf4ca1a1f2c_68cf4c1dc0d6d_star.png', '2025-09-10 13:41:33'),
(5, 1, 'Clown Nose', 'Classic red clown nose for fun', 5.00, 500, '68cf4c945399d_68cf4b85c6b4a_star.png', '2025-09-10 13:41:33'),
(6, 1, 'Vintage Circus Ball', 'Leather juggling ball with medieval design', 20.00, 146, '68cf4c8c05493_68cf4b85c6b4a_star.png', '2025-09-10 13:41:33'),
(7, 1, 'Lion Tamer Whip', 'Decorative whip with steampunk handle', 35.00, 60, '68cf4c820a1fc_68cf4be5d17d4_star.png', '2025-09-10 13:41:33'),
(8, 1, 'Acrobat Figurine', 'Bronze-colored acrobat statue', 40.00, 70, '68cf4c79b9699_68cf4be5d17d4_star.png', '2025-09-10 13:41:33'),
(9, 1, 'Circus Tent Model', 'Miniature tent with detailed fabric', 50.00, 40, '68cf4c704aafa_68cf4c1dc0d6d_star.png', '2025-09-10 13:41:33'),
(10, 1, 'Steampunk Goggles', 'Goggles with brass and leather details', 28.00, 87, '68cf4c64c4b0b_68cf4c1dc0d6d_star.png', '2025-09-10 13:41:33'),
(11, 2, 'Grand Circus Show', 'Main event with acrobats and clowns', 75.00, 200, '68cf4c5ae09f3_68cf4b85c6b4a_star.png', '2025-09-10 13:41:33'),
(12, 2, 'Fire Juggling Spectacle', 'Thrilling fire performance', 60.00, 149, '68cf4c50ec33c_68cf4c1dc0d6d_star.png', '2025-09-10 13:41:33'),
(13, 2, 'Trapeze Extravaganza', 'High-flying trapeze acts', 65.00, 165, '68cf4c45951fe_68cf4b85c6b4a_star.png', '2025-09-10 13:41:33'),
(14, 2, 'Animal Parade', 'Show featuring trained animals', 55.00, 99, '68cf4c3c17a77_68cf4b85c6b4a_star.png', '2025-09-10 13:41:33'),
(15, 2, 'Clown Comedy Night', 'Hilarious clown performances', 50.00, 120, '68cf4c2b25517_star.png', '2025-09-10 13:41:33'),
(16, 2, 'Steampunk Magic Show', 'Magic with a steampunk twist', 70.00, 90, '68cf4c1dc0d6d_star.png', '2025-09-10 13:41:33'),
(17, 2, 'Medieval Jousting Act', 'Circus-style jousting performance', 80.00, 65, '68cf4be5d17d4_star.png', '2025-09-10 13:41:33'),
(18, 2, 'Tightrope Adventure', 'Daring tightrope walking show', 45.00, 110, '68cf4bc1031b2_star.png', '2025-09-10 13:41:33'),
(19, 2, 'Vintage Circus Tour', 'Guided tour of circus history', 30.00, 200, '68cf4b99d1a77_star.png', '2025-09-10 13:41:33'),
(20, 2, 'Family Fun Package', 'All-access pass for family events', 150.00, 50, '68cf4b85c6b4a_star.png', '2025-09-10 13:41:33'),
(23, 3, 'admin', 'special edition :v', 99999999.99, 0, 'gugugaga.jpg', '2025-09-20 16:19:11'),
(26, 3, 'admin tes1', 'xaxa', 99999999.99, 23, '68cf1fba0a647_821720060_17561507982_1757411963194.png', '2025-09-20 21:42:18');

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(11) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `event_date` date NOT NULL,
  `event_time` time NOT NULL,
  `location` varchar(255) NOT NULL,
  `ticket_price` decimal(10,2) NOT NULL,
  `tickets_available` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `event_name`, `event_date`, `event_time`, `location`, `ticket_price`, `tickets_available`, `created_at`) VALUES
(1, 'Grand Circus Spectacular', '2025-10-01', '19:00:00', 'Main Tent', 50000.00, 100, '2025-09-13 02:19:34'),
(2, 'Steampunk Extravaganza', '2025-10-02', '15:00:00', 'West Arena', 75000.00, 50, '2025-09-13 02:19:34');

-- --------------------------------------------------------

--
-- Table structure for table `session_logs`
--

CREATE TABLE `session_logs` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `action` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `purchase_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `customer_id`, `product_id`, `quantity`, `total_price`, `purchase_date`) VALUES
(1, 1, 1, 1, 45.00, '2025-09-10 13:41:33'),
(2, 1, 3, 2, 30.00, '2025-09-10 13:41:33'),
(3, 1, 11, 1, 75.00, '2025-09-10 13:41:33'),
(4, 2, 2, 1, 30.00, '2025-09-10 13:41:33'),
(5, 2, 5, 3, 15.00, '2025-09-10 13:41:33'),
(6, 2, 12, 1, 60.00, '2025-09-10 13:41:33'),
(7, 3, 4, 1, 25.00, '2025-09-10 13:41:33'),
(8, 3, 6, 2, 40.00, '2025-09-10 13:41:33'),
(9, 3, 13, 1, 65.00, '2025-09-10 13:41:33'),
(10, 4, 7, 1, 35.00, '2025-09-10 13:41:33'),
(11, 4, 8, 1, 40.00, '2025-09-10 13:41:33'),
(12, 4, 14, 1, 55.00, '2025-09-10 13:41:33'),
(13, 5, 9, 1, 50.00, '2025-09-10 13:41:33'),
(14, 5, 10, 1, 28.00, '2025-09-10 13:41:33'),
(15, 5, 15, 1, 50.00, '2025-09-10 13:41:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`order_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `session_logs`
--
ALTER TABLE `session_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `product_id` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `session_logs`
--
ALTER TABLE `session_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `order_products`
--
ALTER TABLE `order_products`
  ADD CONSTRAINT `order_products_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_products_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `session_logs`
--
ALTER TABLE `session_logs`
  ADD CONSTRAINT `session_logs_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  ADD CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
