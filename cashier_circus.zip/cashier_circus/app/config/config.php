<?php
// app/config/config.php
define('HOST', 'localhost');
define('DB', 'db_circus');
define('USER', 'root');
define('PASS', '');
define('CHARSET', 'utf8mb4');
?>