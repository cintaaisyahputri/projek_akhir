<?php
// Memproses penambahan kategori
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  include '../middleware/app.php'; // Pastikan untuk menyertakan koneksi database

  // Validasi input
  $name = isset($_POST['category_name']) ? htmlspecialchars(trim($_POST['category_name'])) : '';
  $description = isset($_POST['category_description']) ? htmlspecialchars(trim($_POST['category_description'])) : '';

  // Pastikan semua field terisi
  if (empty($name) || empty($description)) {
    header("Location: ../../public/data_admin.php?error=Semua field harus diisi!"); // Redirect ke halaman error
    exit;
  }

  try {
    $stmt = $pdo->prepare("INSERT INTO categories (name, description) VALUES (?, ?)");
    $stmt->execute([$name, $description]);

    header("Location: ../../public/data_admin.php?success=Kategori berhasil ditambahkan!"); // Arahkan ke daftar kategori
    exit;
  } catch (Exception $e) {
    header("Location: ../../public/data_admin.php?error=Gagal menambahkan kategori: " . urlencode($e->getMessage())); // Redirect ke halaman error
    exit;
  }
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tambah Kategori</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../../public/assets/css/style.css"> <!-- Menambahkan style.css yang sudah ada -->
  <link rel="stylesheet" href="../../public/assets/css/add.css"> <!-- Menambahkan link add.css -->
  <style>
    body {
      background: linear-gradient(to bottom, #f58549, #eec170); /* Tema sirkus: merah ke kuning */
    }

    .container {
      max-width: 600px;
      margin: auto;
      padding: 20px;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    h2 {
      font-size: 1.5rem;
      margin-bottom: 1rem;
      color: #eec170; /* Kuning emas */
    }

    input,
    textarea {
      border: 1px solid #772f1a; /* Sienna untuk border */
      border-radius: 4px;
      padding: 0.5rem;
      width: 100%;
      box-sizing: border-box;
    }

    button {
      background-color: #eec170; /* Kuning emas */
      color: white;
      padding: 0.5rem;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    button:hover {
      background-color: #f58549; /* Merah saat hover */
    }
  </style>
</head>

<body>
  <div class="container mt-6">
    <h2 class="text-2xl font-semibold mb-4">Tambah Kategori</h2>
    <form id="addCategoryForm" method="POST">
      <div class="mb-4">
        <label class="block text-sm font-medium">Nama Kategori</label>
        <input type="text" name="category_name" required placeholder="Masukkan nama kategori">
      </div>
      <div class="mb-4">
        <label class="block text-sm font-medium">Deskripsi Kategori</label>
        <textarea name="category_description" required placeholder="Masukkan deskripsi kategori"></textarea>
      </div>
      <button type="submit">Tambah Kategori</button>
    </form>
  </div>
</body>