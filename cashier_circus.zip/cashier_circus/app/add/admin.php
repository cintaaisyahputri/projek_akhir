<?php

include '../middleware/app.php';

$error = ''; // Variable to store error messages

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = htmlspecialchars(trim($_POST['admin_name']));
  $email = filter_var(trim($_POST['admin_email']), FILTER_VALIDATE_EMAIL);
  $password = $_POST['admin_password'];

  if (!$name || !$email || !$password) {
    $error = "Semua field harus diisi dengan benar.";
  } else {
    if (addAdmin($name, $email, $password)) {
      header("Location: ../../public/data_admin.php?success=Admin berhasil ditambahkan!");
      exit;
    } else {
      $error = "Gagal menambahkan admin.";
    }
  }
}

function addAdmin($name, $email, $password)
{
  global $pdo;

  // Hash the password for security
  $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

  try {
    // Memastikan email unik sebelum menambah admin
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM admins WHERE email = ?");
    $stmt->execute([$email]);
    $count = $stmt->fetchColumn();

    if ($count > 0) {
      return false; // Email sudah terdaftar
    }
    $stmt = $pdo->prepare("INSERT INTO admins (name, email, password) VALUES (?, ?, ?)");
    $stmt->execute([$name, $email, $hashedPassword]);

    return true; // Success
  } catch (Exception $e) {
    return false; // Failure
  }
}

?>

<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tambah Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../../public/assets/css/style.css"> <!-- Menambahkan style.css yang sudah ada -->
  <link rel="stylesheet" href="../../public/assets/css/add.css"> <!-- Menambahkan link add.css -->
  <style>
    body {
      background: linear-gradient(to bottom, #f58549, #eec170); /* Tema sirkus: merah ke kuning */
    }

    .container {
      max-width: 500px;
      margin: auto;
      padding: 20px;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
      font-size: 1.5rem;
      margin-bottom: 1rem;
      color: #eec170; /* Kuning emas untuk judul */
    }

    label {
      font-weight: 500;
      color: #eec170; /* Kuning untuk label */
    }

    input {
      border: 1px solid #772f1a; /* Sienna untuk border */
      border-radius: 4px;
      padding: 0.5rem;
      width: 100%;
      box-sizing: border-box;
    }

    button {
      width: 100%;
      padding: 0.5rem;
      background-color: #eec170; /* Kuning emas untuk tombol */
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    button:hover {
      background-color: #f58549; /* Merah saat hover */
    }
  </style>
</head>

<body>
  <div class="container">
    <h1>Tambah Admin</h1>
    <?php if ($error): ?>
      <div class="mb-4 text-red-600 text-sm"><?php echo $error; ?></div>
    <?php endif; ?>
    <form method="POST" action="">
      <div class="mb-4">
        <label for="admin_name">Nama</label>
        <input type="text" name="admin_name" id="admin_name" required>
      </div>
      <div class="mb-4">
        <label for="admin_email">Email</label>
        <input type="email" name="admin_email" id="admin_email" required>
      </div>
      <div class="mb-4">
        <label for="admin_password">Kata Sandi</label>
        <input type="password" name="admin_password" id="admin_password" required>
      </div>
      <button type="submit">Tambah Admin</button>
    </form>
  </div>
</body>

</html>