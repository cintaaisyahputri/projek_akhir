<?php

include '../middleware/app.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $productName = htmlspecialchars(trim($_POST['product_name']));
  $categoryId = htmlspecialchars(trim($_POST['category_id'])); // Mengambil ID kategori dari dropdown
  $price = str_replace('.', '', $_POST['price']); // hilangkan titik ribuan
  $price = filter_var($price, FILTER_SANITIZE_NUMBER_FLOAT);  

  $stock = htmlspecialchars(trim($_POST['stock']));

  // Validasi input
  if (!$productName || !$categoryId || !is_numeric($price) || !is_numeric($stock) || $price <= 0 || $stock < 0) {
    header("Location: ../../public/data_admin.php?error=Semua field harus diisi dengan benar dan harga harus lebih dari 0, stok tidak boleh negatif.");
    exit();
  } else {
    // Menambahkan produk ke database
    try {
      $stmt = $pdo->prepare("INSERT INTO products (name, category_id, price, stock) VALUES (?, ?, ?, ?)");
      $stmt->execute([$productName, $categoryId, $price, $stock]);
      header("Location: ../../public/data_admin.php?success=Produk berhasil ditambahkan!");
      exit();
    } catch (Exception $e) {
      header("Location: ../../public/data_admin.php?error=Gagal menambahkan produk: " . urlencode($e->getMessage()));
      exit();
    }
  }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tambah Produk</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css">
  <link rel="stylesheet" href="../../public/assets/css/style.css"> <!-- Menambahkan style.css yang sudah ada -->
  <link rel="stylesheet" href="../../public/assets/css/add.css"> <!-- Menambahkan link add.css -->
  <style>
    body {
      background: linear-gradient(to bottom, #f58549, #eec170); /* Tema sirkus: merah ke kuning */
    }

    .container {
      max-width: 600px;
      margin: auto;
      padding: 20px;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
      font-size: 2rem;
      margin-bottom: 1rem;
      color: #eec170; /* Kuning emas */
    }

    label {
      font-weight: 500;
      color: #eec170; /* Kuning untuk label */
    }

    input,
    select {
      border: 1px solid #772f1a; /* Sienna untuk border */
      border-radius: 4px;
      padding: 0.5rem;
      width: 100%;
      box-sizing: border-box;
    }

    button {
      background-color: #eec170; /* Kuning emas */
      color: white;
      padding: 0.5rem;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    button:hover {
      background-color: #f58549; /* Merah saat hover */
    }
  </style>
</head>

<body>
  <div class="container mx-auto p-6">
    <h1 class="text-3xl font-bold mb-4">Tambah Produk</h1>
    <form method="POST">
      <div class="mb-4">
        <label for="product_name" class="block text-sm font-medium text-gray-700">Nama Produk</label>
        <input type="text" id="product_name" name="product_name" required />
      </div>
      <div class="mb-4">
        <label for="category_id" class="block text-sm font-medium text-gray-700">Kategori</label>
        <select id="category_id" name="category_id" required>
          <option value="">Pilih Kategori</option>
          <?php
          // Mengambil kategori dari database untuk dropdown
          $stmt = $pdo->query("SELECT id, name FROM categories");
          while ($category = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo '<option value="' . htmlspecialchars($category['id']) . '">' . htmlspecialchars($category['name']) . '</option>';
          }
          ?>
        </select>
      </div>
      <div class="mb-4">
        <label for="price" class="block text-sm font-medium text-gray-700">Harga</label>
        <input type="number" id="price" name="price" required min="0" />
      </div>
      <div class="mb-4">
        <label for="stock" class="block text-sm font-medium text-gray-700">Stok</label>
        <input type="number" id="stock" name="stock" required min="0" />
      </div>
      <button type="submit">Tambah Produk</button>
    </form>
    <script>
function formatRupiah(input) {
    let value = input.value.replace(/\D/g, "");
    input.value = value.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}
</script>
  
  </div>
</body>

</html>