<?php
// app/middleware/app.php
require_once __DIR__ . '/../config/config.php';

function connection() {
    try {
        $dsn = "mysql:host=" . HOST . ";dbname=" . DB . ";charset=" . CHARSET;
        $pdo = new PDO($dsn, USER, PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        error_log("Connection failed: " . $e->getMessage());
        die("Connection failed. Please check your configuration.");
    }
}

$pdo = connection();

if (!isset($_SESSION)) {
    session_start();
}
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>