## Deskripsi Aplikasi 
Source Code Aplikasi Penjualan Barang sederhana berbasis Website dengan PHP & MYSQL.

## Tentang Royal Circus POS

**Royal Circus POS** adalah sistem Point of Sale (POS) berbasis web yang dirancang untuk mengelola transaksi penjualan tiket, merchandise, dan layanan pertunjukan sirkus dengan tema steampunk dan medieval. Aplikasi ini dibuat menggunakan PHP dan MySQL, dengan antarmuka yang menarik dan interaktif, termasuk animasi partikel, efek confetti, dan desain bertema sirkus kerajaan.

### Fitur Utama
- **Manajemen Produk**: Tambah, edit, atau hapus produk seperti tiket sirkus dan merchandise dengan mudah.  
- **Transaksi Penjualan**: Proses pembelian tiket atau barang dengan cepat, termasuk pencetakan struk.  
- **Laporan Penjualan**: Lihat laporan penjualan harian, mingguan, atau bulanan untuk analisis performa sirkus.  
- **Pengelolaan Pelanggan**: Simpan data pelanggan untuk mempermudah transaksi berulang.  


### Teknologi yang Digunakan
- **Bahasa Pemrograman**: PHP, JavaScript  
- **Database**: MySQL  
- **Framework CSS**: Tailwind CSS, Bootstrap (opsional)  
- **Library Tambahan**: Particles.js, Canvas Confetti  
- **Font**: MedievalSharp, circusant, circusparty, mevno1, mevno2  
- **Alat Pengembangan**: Git  

### Cara Menjalankan Aplikasi
1. **Persyaratan**:  
   - Server dengan PHP (versi 8.2 atau lebih tinggi) dan MySQL (MariaDB 10.4 atau lebih tinggi).  
   - Web server seperti Apache atau Nginx.  
   - Git untuk mengelola kode sumber.  

2. **Langkah Instalasi**:  
   - Clone repository ini:  
     ```bash
     git clone <URL_REPOSITORY_ANDA>