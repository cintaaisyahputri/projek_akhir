<?php
session_start();
require 'app/middleware/app.php';

if (isset($_SESSION['admin_name']) || isset($_SESSION['user_name'])) {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET' || !empty($_POST)) {
        header('Location: index.php');
        exit();
    }
}

$error_message = '';
$admin = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $role = $_POST['role'] ?? 'admin';

    if ($role === 'admin') {
        $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = :email");
        $stmt->execute(['email' => $email]);
        $admin = $stmt->fetch();

        if ($admin) {
            if (password_verify($password, $admin['password'])) {
                $_SESSION['admin_name'] = $admin['name'];
                $_SESSION['role'] = 'admin';
                header('Location: index.php');
                exit();
            } else {
                $error_message = 'Password salah! Silakan coba lagi.';
            }
        } else {
            $error_message = 'Email tidak ditemukan! Silakan periksa kembali.';
        }
    } elseif ($role === 'user') {
        $stmt = $pdo->prepare("SELECT * FROM customers WHERE email = :email");
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch();

        if ($user) {
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['role'] = 'user';
                header('Location: index.php');
                exit();
            } else {
                $error_message = 'Password salah! Silakan coba lagi.';
            }
        } else {
            $error_message = 'Email tidak ditemukan! Silakan hubungi ringmaster sirkus.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter Royal Circus</title>
    <link href="https://fonts.googleapis.com/css2?family=MedievalSharp&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="public/assets/css/circus-login.css">
    <link rel="stylesheet" href="public/assets/css/circus-footer.css">
    <script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
</head>
<body>
    <div id="particles-js"></div>
    <div class="container">
        <div class="container__logo">
            <img src="public/assets/images/logo.png" alt="Royal Circus Logo" class="w-full h-auto">
        </div>
        <h1 class="text-3xl font-bold text-center mb-6">Enter Royal Circus</h1>
        <?php if ($error_message): ?>
            <div class="text-red-500 text-center mb-4"><?= htmlspecialchars($error_message) ?></div>
        <?php endif; ?>
        <form method="POST" class="max-w-md mx-auto bg-gray-800 p-6 rounded-lg shadow-lg">
            <div class="mb-4">
                <label class="block text-sm font-medium">Email</label>
                <input type="email" name="email" required class="w-full p-2 border rounded bg-gray-700 text-white">
            </div>
            <div class="mb-4 relative">
                <label class="block text-sm font-medium">Password</label>
                <input type="password" name="password" id="password" required class="w-full p-2 border rounded bg-gray-700 text-white">
                <span class="eye-icon absolute right-2 top-1/2 -translate-y-1/2 cursor-pointer">👁️</span>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium">Role</label>
                <select name="role" class="w-full p-2 border rounded bg-gray-700 text-white">
                    <option value="admin">Ringmaster (Admin)</option>
                    <option value="user">Patron (User)</option>
                </select>
            </div>
            <button type="submit" class="w-full p-2 bg-red-600 text-white rounded hover:bg-red-700">Buka Gerbang Sirkus Kerajaan!</button>
        </form>
        <div class="marquee-container">
            <marquee behavior="scroll" direction="left" scrollamount="5">
                <span class="slogan">Perform with Pride, Amaze with Grace – Royal Circus Awaits Your Mystic Spectacle!</span>
            </marquee>
        </div>
    </div>
    <?php include 'footer.php'; ?>

    <script>
        particlesJS("particles-js", {
            particles: {
                number: { value: 50 },
                color: { value: "#d09259" },
                shape: { type: "star" },
                opacity: { value: 0.7 },
                size: { value: 4 },
                line_linked: {
                    enable: true,
                    distance: 100,
                    color: "#e4ceaf",
                    opacity: 0.3,
                    width: 1
                },
                move: {
                    enable: true,
                    speed: 2,
                    direction: "none",
                    random: true,
                    straight: false,
                    out_mode: "bounce",
                    bounce: true
                }
            },
            interactivity: {
                detect_on: "canvas",
                events: {
                    onhover: { enable: true, mode: "grab" },
                    onclick: { enable: true, mode: "repulse" },
                    resize: true
                },
                modes: {
                    grab: { distance: 150 },
                    repulse: { distance: 100 }
                }
            },
            retina_detect: true
        });
        document.querySelector('.eye-icon').addEventListener('click', () => {
            const passwordInput = document.getElementById('password');
            passwordInput.type = passwordInput.type === 'password' ? 'text' : 'password';
        });
    </script>
</body>
</html>