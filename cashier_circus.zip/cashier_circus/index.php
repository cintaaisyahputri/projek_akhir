<?php
session_start();

if (!isset($_SESSION['admin_name'])) {
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Royal Circus Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=MedievalSharp&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="public/assets/css/index.css">
    <link rel="stylesheet" href="public/assets/css/circus-footer.css">
    <script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>
</head>
<body>
    <div id="particles-js"></div>
    <div class="frame-container">
        <img src="public/assets/images/header.png" class="frame-decoration frame-bottom-center" alt="Frame Bottom Center">
        <img src="public/assets/images/logo.png" class="circus-photo" alt="Grand Circus Tent in Medieval Splendor">
        <div class="welcome-container">
            <h1 class="welcome-text">Selamat Datang, CINTA!</h1>
            <h2 class="animate__animated animate__fadeInDown animate__delay-2s">Pilih Menu</h2>
        </div>
        <div class="marquee-container">
            <marquee behavior="scroll" direction="left" scrollamount="5">
                <span class="slogan">Perform with Pride, Amaze with Grace – Royal Circus Awaits Your Mystic Spectacle!</span>
            </marquee>
        </div>

        <nav class="animate__animated animate__fadeInDown animate__delay-2s">
            <a href="public/dashboard.php" class="nav-link">Dashboard</a>
            <a href="public/order.php" class="nav-link">Pesanan</a>
            <a href="public/data_admin.php" class="nav-link">Data Admin</a>
            <a href="public/logout.php" class="nav-link">Keluar</a>
        </nav>

        <h3 class="animate__animated animate__fadeInDown animate__delay-2s">Fitur Kerajaan</h3>
        <div class="features animate__animated animate__fadeInRight animate__delay-2s">
            <div class="card">
                <h4>Laporan Penjualan</h4>
                <p>Lihat laporan penjualan tiket sirkus, merchandise, dan layanan pertunjukan harian, mingguan, dan bulanan.</p>
            </div>
        </div>
        <div class="features animate__animated animate__fadeInLeft animate__delay-2s">
            <div class="card">
                <h4>Notifikasi Pesanan</h4>
                <p>Dapatkan notifikasi untuk setiap pesanan tiket atau permintaan pertunjukan baru.</p>
            </div>
        </div>
        <div class="marquee-container">
            <marquee behavior="scroll" direction="left" scrollamount="5">
                <span class="slogan">Perform with Pride, Amaze with Grace – Royal Circus Awaits Your Mystic Spectacle!</span>
            </marquee>
        </div>

        <button class="confetti-button" onclick="triggerConfetti()">Luncurkan Konfeti Sirkus!</button>

        <?php include 'footer.php'; ?>
    </div>

    <script>
        particlesJS("particles-js", {
            particles: {
                number: { value: 50 },
                color: { value: "#B8860B" },
                shape: { type: "star" },
                opacity: { value: 0.7 },
                size: { value: 4 },
                line_linked: {
                    enable: true,
                    distance: 100,
                    color: "#4A3723",
                    opacity: 0.3,
                    width: 1
                },
                move: {
                    enable: true,
                    speed: 2,
                    direction: "none",
                    random: true,
                    straight: false,
                    out_mode: "bounce",
                    bounce: true
                }
            },
            interactivity: {
                detect_on: "canvas",
                events: {
                    onhover: { enable: true, mode: "grab" },
                    onclick: { enable: true, mode: "repulse" },
                    resize: true
                },
                modes: {
                    grab: { distance: 150 },
                    repulse: { distance: 100 }
                }
            },
            retina_detect: true
        });

        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('mouseenter', () => {
                link.style.transition = 'all 0.3s ease';
                link.style.transform = 'scale(1.1) rotate(3deg)';
                link.style.background = 'linear-gradient(45deg, #B8860B, #4A3723)';
                link.style.boxShadow = '0 8px 20px rgba(0, 0, 0, 0.5)';
            });
            link.addEventListener('mouseleave', () => {
                link.style.transform = 'scale(1) rotate(0deg)';
                link.style.background = 'rgba(255, 255, 255, 0.15)';
                link.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.3)';
            });
        });

        function triggerConfetti() {
            confetti({
                particleCount: 100,
                spread: 70,
                origin: { y: 0.6 },
                colors: ['#B8860B', '#4A3723', '#D9C2A6']
            });
        }
    </script>
</body>
</html>